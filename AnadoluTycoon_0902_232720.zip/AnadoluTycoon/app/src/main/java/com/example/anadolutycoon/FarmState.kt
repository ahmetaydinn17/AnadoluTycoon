package com.example.anadolutycoon

data class FarmState(
    val money: Int,
    val inventory: Map<Product, Int>,
    val slots: List<TarlaSlot>,

    // ✅ Piyasa fiyatları (TEK satış fiyatı)
    val marketPrices: Map<Product, Int>,

    // ✅ Bir sonraki piyasa güncelleme zamanı (millis)
    val nextMarketUpdateAt: Long
)
