package com.example.anadolutycoon

data class Factory(
    val id: String,
    val icon: String,
    val name: String,

    val input: Product,
    val inputQty: Int,        // 1 üretim için girdi adedi

    val output: Product,
    val outputQty: Int,       // 1 üretim için çıktı adedi

    val workSeconds: Int,     // ✅ 1 üretimin süresi (baz süre)

    // ✅ Runtime state (kaydetmek istersen ayrıca store yaparsın)
    var isWorking: Boolean = false,
    var startedAt: Long = 0L,
    var totalSeconds: Int = 0,
    var plannedCount: Int = 0 // ✅ kaç üretim planlandı (qty)
)
