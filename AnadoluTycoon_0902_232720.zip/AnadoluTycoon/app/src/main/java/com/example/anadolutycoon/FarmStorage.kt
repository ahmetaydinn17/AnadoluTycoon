package com.example.anadolutycoon

import android.content.Context
import com.google.gson.Gson
import com.google.gson.GsonBuilder

class FarmStorage(context: Context) {

    private val prefs = context.getSharedPreferences("farm_storage", Context.MODE_PRIVATE)

    private val gson: Gson = GsonBuilder().create()

    fun save(state: FarmState) {
        val json = gson.toJson(state)
        prefs.edit().putString("state_json", json).apply()
    }

    fun load(): FarmState? {
        val json = prefs.getString("state_json", null) ?: return null
        return try {
            gson.fromJson(json, FarmState::class.java)
        } catch (_: Exception) {
            null
        }
    }

    fun clear() {
        prefs.edit().remove("state_json").apply()
    }
}
