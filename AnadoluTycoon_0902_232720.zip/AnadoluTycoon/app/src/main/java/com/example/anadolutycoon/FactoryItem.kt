package com.example.anadolutycoon

data class FactoryItem(
    var isReadyToCollect: Boolean = false,

    val id: String,
    val title: String,
    val emoji: String,
    val input: List<Pair<Product, Int>>,
    val output: Pair<Product, Int>,
    val seconds: Int,
    var isUnlocked: Boolean = true,
    var unlockPrice: Int = 0,
    var isRunning: Boolean = false,
    var startedAt: Long = 0L

)
