package com.example.anadolutycoon

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainMenuActivity : AppCompatActivity() {

    private lateinit var tvMoney: TextView
    private lateinit var tvCenter: TextView
    private lateinit var tvTime: TextView

    private lateinit var moneyStore: GlobalMoneyStore
    private lateinit var marketStore: MarketStore

    private val handler = Handler(Looper.getMainLooper())
    private val clockRunnable = object : Runnable {
        override fun run() {
            tvTime.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_menu)

        moneyStore = GlobalMoneyStore(this)
        marketStore = MarketStore(this)

        tvMoney = findViewById(R.id.tvTopMoney)
        tvCenter = findViewById(R.id.tvTopCenter)
        tvTime = findViewById(R.id.tvTopTime)

        tvCenter.text = "ANA MERKEZ"

        // ✅ Genel Depo
        findViewById<MaterialButton>(R.id.btnGlobalDepot).setOnClickListener {
            startActivity(Intent(this, GlobalDepotActivity::class.java))
        }

        // ✅ Piyasalar (Ana Menüde)
        // activity_main_menu.xml içine btnMarket eklemelisin.
        findViewById<MaterialButton>(R.id.btnMarket).setOnClickListener {
            showMarketDialog()
        }

        // ✅ KARTLAR
        findViewById<MaterialCardView>(R.id.cardKoy).setOnClickListener {
            startActivity(Intent(this, FarmActivity::class.java))
        }

        findViewById<MaterialCardView>(R.id.cardSehir).setOnClickListener {
            startActivity(Intent(this, CityActivity::class.java))
        }

        findViewById<MaterialCardView>(R.id.cardOsb).setOnClickListener {
            startActivity(Intent(this, OsbActivity::class.java))
        }

        findViewById<MaterialCardView>(R.id.cardKucukOsb).setOnClickListener {
            startActivity(Intent(this, SmallOsbActivity::class.java))
        }

        findViewById<MaterialCardView>(R.id.cardMadencilik).setOnClickListener {
            startActivity(Intent(this, MiningActivity::class.java))
        }

        findViewById<MaterialCardView>(R.id.cardHayvancilik).setOnClickListener {
            startActivity(Intent(this, LivestockActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        refreshTopBar()
        handler.post(clockRunnable)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(clockRunnable)
    }

    private fun refreshTopBar() {
        val money = moneyStore.getMoney()
        tvMoney.text = "💰 ${formatMoney(money)} ₺"
    }

    private fun formatMoney(v: Int): String {
        val s = v.toString()
        val sb = StringBuilder()
        for (i in s.indices) {
            sb.append(s[i])
            val left = s.length - i - 1
            if (left > 0 && left % 3 == 0) sb.append('.')
        }
        return sb.toString()
    }

    // ----------------------------
    // ✅ PİYASA DIALOG (Ana Menü)
    // ----------------------------
    private fun showMarketDialog() {
        marketStore.ensureUpToDate()

        val v = layoutInflater.inflate(R.layout.dialog_market, null)
        val lv = v.findViewById<ListView>(R.id.lvMarket)
        val btnClose = v.findViewById<TextView>(R.id.btnClose)

        val rows: List<MarketRow> = Product.values().map { p ->
            MarketRow(p, marketStore.unitPrice(p), marketStore.bulkUnitPrice(p))
        }

        lv.adapter = MarketListAdapter(this, rows)

        val dlg = AlertDialog.Builder(this)
            .setTitle("Piyasalar (Güncellenme: ${marketStore.getRemainingSec()}s)")
            .setView(v)
            .create()

        btnClose.setOnClickListener { dlg.dismiss() }
        dlg.show()
    }
}
