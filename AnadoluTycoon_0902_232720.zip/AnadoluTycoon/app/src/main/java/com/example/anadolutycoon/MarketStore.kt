package com.example.anadolutycoon

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlin.math.max
import kotlin.random.Random

class MarketStore(context: Context) {

    private val prefs = context.getSharedPreferences("market_store", Context.MODE_PRIVATE)
    private val gson = Gson()

    private val KEY_PRICES = "prices_json"
    private val KEY_NEXT_AT = "next_update_at"

    companion object {
        const val PERIOD_MS = 60_000L // 1 dk
    }

    fun getNextUpdateAt(): Long = prefs.getLong(KEY_NEXT_AT, 0L)

    fun getRemainingSec(): Long {
        val now = System.currentTimeMillis()
        return max(0L, (getNextUpdateAt() - now) / 1000L)
    }

    fun getPrices(): MutableMap<Product, Int> {
        val json = prefs.getString(KEY_PRICES, null) ?: return mutableMapOf()
        return try {
            val type = object : TypeToken<MutableMap<Product, Int>>() {}.type
            gson.fromJson(json, type) ?: mutableMapOf()
        } catch (_: Exception) {
            mutableMapOf()
        }
    }

    private fun savePrices(map: Map<Product, Int>) {
        prefs.edit().putString(KEY_PRICES, gson.toJson(map)).apply()
    }

    private fun setNextUpdateAt(timeMs: Long) {
        prefs.edit().putLong(KEY_NEXT_AT, timeMs).apply()
    }

    fun ensureUpToDate() {
        val now = System.currentTimeMillis()

        var prices = getPrices()
        var nextAt = getNextUpdateAt()

        // ilk kurulum
        if (prices.isEmpty() || nextAt == 0L) {
            prices = mutableMapOf<Product, Int>().apply {
                for (p in Product.values()) put(p, p.baseSellPrice)
            }
            savePrices(prices)
            setNextUpdateAt(now + PERIOD_MS)
            return
        }

        // zamanı geldiyse güncelle
        if (now >= nextAt) {
            val newMap = mutableMapOf<Product, Int>()
            for (p in Product.values()) {
                val base = p.baseSellPrice
                val delta = (base * 0.20f).toInt() // +- %20
                val newPrice = (base + Random.nextInt(-delta, delta + 1)).coerceAtLeast(1)
                newMap[p] = newPrice
            }
            savePrices(newMap)
            setNextUpdateAt(now + PERIOD_MS)
        }
    }

    fun unitPrice(p: Product): Int {
        ensureUpToDate()
        return getPrices()[p] ?: p.baseSellPrice
    }

    fun bulkUnitPrice(p: Product): Int {
        val u = unitPrice(p)
        return max(1, (u * 0.95f).toInt())
    }
}
