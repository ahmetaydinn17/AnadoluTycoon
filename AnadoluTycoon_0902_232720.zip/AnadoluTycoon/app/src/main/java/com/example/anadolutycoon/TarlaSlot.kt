package com.example.anadolutycoon

enum class SlotPhase { IDLE, PLANTED, GROWING, READY, HARVESTING }

data class TarlaSlot(
    val id: Int,
    var isUnlocked: Boolean,
    var acresOwned: Int,
    var unlockPrice: Int,
    var acrePrice: Int
) {
    var product: Product? = null

    var phase: SlotPhase = SlotPhase.IDLE
    var phaseStartedAt: Long = 0L

    var workerCount: Int = 0
    var irrigationLevel: Int = 0
    var fertilizerLevel: Int = 0

    // animasyon tetiklemek için
    var lastHarvestedAt: Long = 0L
}
