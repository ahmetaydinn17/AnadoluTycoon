package com.example.anadolutycoon

import android.content.Context

class GlobalMoneyStore(context: Context) {

    private val prefs = context.getSharedPreferences("global_money", Context.MODE_PRIVATE)

    fun getMoney(): Int = prefs.getInt("money", 0)
    fun addMoney(amount: Int) {
        setMoney(getMoney() + amount.coerceAtLeast(0))
    }


    fun setMoney(value: Int) {
        prefs.edit().putInt("money", value.coerceAtLeast(0)).apply()
    }

    /** Yeterli para varsa düşer ve true döner. Yoksa false. */
    fun trySpend(amount: Int): Boolean {
        val a = amount.coerceAtLeast(0)
        val cur = getMoney()
        if (cur < a) return false
        setMoney(cur - a)
        return true
    }

    fun add(amount: Int) {
        val a = amount.coerceAtLeast(0)
        setMoney(getMoney() + a)
    }
}
