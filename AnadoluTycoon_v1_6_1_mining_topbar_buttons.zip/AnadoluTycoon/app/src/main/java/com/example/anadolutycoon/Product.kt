package com.example.anadolutycoon

enum class Product(
    val title: String,
    val emoji: String,
    val baseSellPrice: Int,
    val seedCostPerAcre: Int,
    val yieldPerAcre: Int,
    val plantSeconds: Int,
    val growSeconds: Int,
    val harvestSeconds: Int,
    val canPlant: Boolean = true // ✅ default: true (ekilebilen)
) {
    // 🌱 TARLA (ekilebilir)
    ELMA("Elma", "🍎", 24, 70, 10, 8, 25, 5),
    LIMON("Limon", "🍋", 25, 75, 10, 9, 28, 6),
    BUGDAY("Buğday", "🌾", 4, 30, 30, 6, 18, 4),
    SEKER_PANCARI("Şeker Pancarı", "🥬", 7, 50, 20, 7, 20, 5),
    PATATES("Patates", "🥔", 6, 45, 20, 7, 22, 5),
    DOMATES("Domates", "🍅", 5, 50, 25, 8, 24, 6),
    BIBER("Biber", "🫑", 14, 70, 15, 9, 26, 6),
    CILEK("Çilek", "🍓", 18, 80, 15, 10, 28, 7),
    KAVUN("Kavun", "🍈", 16, 90, 10, 10, 30, 7),
    PORTAKAL("Portakal", "🍊", 15, 80, 10, 10, 30, 7),
    AYVA("Ayva", "🍐", 17, 85, 10, 10, 32, 7),

    // 🏭 KÜÇÜK OSB (ekilemez)
    YEM("Yem", "🐄", 12, 0, 0, 0, 0, 0, false),
    SALCA("Salça", "🥫", 35, 0, 0, 0, 0, 0, false),
    UN("Un", "🌾", 18, 0, 0, 0, 0, 0, false),
    RECEL("Reçel", "🍯", 45, 0, 0, 0, 0, 0, false),
    KURUT_DOMATES("Kurutulmuş Domates", "☀️🍅", 40, 0, 0, 0, 0, 0, false),
    KURUT_BIBER("Kurutulmuş Biber", "☀️🫑", 42, 0, 0, 0, 0, 0, false),
    // 🐄 HAYVANCILIK (ekilemez)
    SUT("Süt", "🥛", 20, 0, 0, 0, 0, 0, false),
    YUMURTA("Yumurta", "🥚", 10, 0, 0, 0, 0, 0, false),
    PEYNIR("Peynir", "🧀", 55, 0, 0, 0, 0, 0, false),

    // ⛏️ MADENCİLİK / ORMANCILIK (ekilemez)
    ODUN("Odun", "🪵", 6, 0, 0, 0, 0, 0, false),
    KOMUR("Kömür", "🪨", 8, 0, 0, 0, 0, 0, false),
    DEMIR_CEVHER("Demir Cevheri", "⛓️", 15, 0, 0, 0, 0, 0, false),

    // 🏭 OSB (ekilemez)
    CELIK("Çelik", "⚙️", 60, 0, 0, 0, 0, 0, false),
    EKMEK("Ekmek", "🍞", 22, 0, 0, 0, 0, 0, false),

}
