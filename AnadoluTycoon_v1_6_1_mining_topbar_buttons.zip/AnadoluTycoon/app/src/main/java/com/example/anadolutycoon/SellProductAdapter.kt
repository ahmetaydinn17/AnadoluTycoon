package com.example.anadolutycoon

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView

class SellProductAdapter(
    private val context: Context,
    private val products: List<Product>,
    private val inventory: Map<Product, Int>,
    private val getUnitPrice: (Product, Int) -> Int,
    private val onSellQty: (Product, Int) -> Unit,
    private val onSellAll: (Product) -> Unit
) : BaseAdapter() {

    override fun getCount() = products.size
    override fun getItem(position: Int) = products[position]
    override fun getItemId(position: Int) = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val v = convertView ?: LayoutInflater.from(context).inflate(android.R.layout.simple_list_item_2, parent, false)
        val p = products[position]
        val stock = inventory[p] ?: 0

        val t1 = v.findViewById<TextView>(android.R.id.text1)
        val t2 = v.findViewById<TextView>(android.R.id.text2)

        val single = getUnitPrice(p, 1)
        val bulk = getUnitPrice(p, 100)

        t1.text = "${p.emoji} ${p.title} (Stok: $stock)"
        t2.text = "Tek: ${single}₺ | 100+: ${bulk}₺"

        v.setOnClickListener {
            if (stock > 0) onSellQty(p, 1)
        }
        v.setOnLongClickListener {
            if (stock > 0) onSellAll(p)
            true
        }

        return v
    }
}
