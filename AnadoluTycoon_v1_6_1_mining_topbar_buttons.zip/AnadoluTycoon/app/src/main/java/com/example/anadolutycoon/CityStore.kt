package com.example.anadolutycoon

import android.content.Context
import kotlin.math.max

class CityStore(context: Context) {

    enum class Shop { MANAV, TOPTANCI, IHRACAT }

    private val prefs = context.getSharedPreferences("city_store", Context.MODE_PRIVATE)
    private fun key(shop: Shop) = "shop_level_${shop.name}"

    fun getLevel(shop: Shop): Int = max(1, prefs.getInt(key(shop), 1))

    fun shopTitle(shop: Shop): String = when (shop) {
        Shop.MANAV -> "Manav"
        Shop.TOPTANCI -> "Toptancı"
        Shop.IHRACAT -> "İhracat"
    }

    fun getMultiplier(shop: Shop): Float {
        val lv = getLevel(shop)
        val base = when (shop) {
            Shop.MANAV -> 1.05f
            Shop.TOPTANCI -> 1.12f
            Shop.IHRACAT -> 1.20f
        }
        return base + (lv - 1) * 0.04f
    }

    fun bestMultiplier(): Float = maxOf(
        getMultiplier(Shop.MANAV),
        getMultiplier(Shop.TOPTANCI),
        getMultiplier(Shop.IHRACAT)
    )

    fun upgradeCost(shop: Shop): Int {
        val lv = getLevel(shop)
        val base = when (shop) {
            Shop.MANAV -> 900
            Shop.TOPTANCI -> 1500
            Shop.IHRACAT -> 2500
        }
        return base * lv
    }

    fun upgrade(shop: Shop) {
        val lv = getLevel(shop)
        prefs.edit().putInt(key(shop), lv + 1).apply()
    }
}
