package com.example.anadolutycoon

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView

data class MarketRow(
    val product: Product,
    val single: Int,
    val bulk: Int
)

class MarketListAdapter(
    private val context: Context,
    private val items: List<MarketRow>
) : BaseAdapter() {

    override fun getCount() = items.size
    override fun getItem(position: Int) = items[position]
    override fun getItemId(position: Int) = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val v = convertView ?: LayoutInflater.from(context)
            .inflate(R.layout.item_market_row, parent, false)

        val row = items[position]

        v.findViewById<TextView>(R.id.tvName).text =
            "${row.product.emoji} ${row.product.title}"

        v.findViewById<TextView>(R.id.tvSingle).text =
            "${row.single} TL"

        v.findViewById<TextView>(R.id.tvBulk).text =
            "${row.bulk} TL"

        return v
    }
}
