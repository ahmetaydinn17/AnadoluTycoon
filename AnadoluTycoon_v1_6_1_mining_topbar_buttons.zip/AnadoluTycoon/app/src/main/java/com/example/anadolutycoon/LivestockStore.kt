package com.example.anadolutycoon

import android.content.Context
import kotlin.math.max

class LivestockStore(context: Context) {
    private val prefs = context.getSharedPreferences("livestock_store", Context.MODE_PRIVATE)

    fun getCows(): Int = max(0, prefs.getInt("cows", 0))
    fun getChickens(): Int = max(0, prefs.getInt("chickens", 0))

    fun setCows(v: Int) = prefs.edit().putInt("cows", max(0, v)).apply()
    fun setChickens(v: Int) = prefs.edit().putInt("chickens", max(0, v)).apply()

    fun getLastCollectMilk(): Long = prefs.getLong("last_collect_milk", System.currentTimeMillis())
    fun getLastCollectEgg(): Long = prefs.getLong("last_collect_egg", System.currentTimeMillis())

    fun setLastCollectMilk(v: Long) = prefs.edit().putLong("last_collect_milk", v).apply()
    fun setLastCollectEgg(v: Long) = prefs.edit().putLong("last_collect_egg", v).apply()
}
