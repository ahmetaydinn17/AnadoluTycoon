package com.example.anadolutycoon

data class DepotSummaryRow(
    val map: MapType,
    val total: Int,
    val top3: String
)
