package com.example.anadolutycoon

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import kotlin.math.max
import kotlin.random.Random

class MiningActivity : AppCompatActivity() {

    private lateinit var depotStore: DepotStore
    private lateinit var moneyStore: GlobalMoneyStore
    private lateinit var miningStore: MiningStore

    private val handler = Handler(Looper.getMainLooper())
    private var ticker: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mining)

        depotStore = DepotStore(this)
        moneyStore = GlobalMoneyStore(this)
        miningStore = MiningStore(this)

        val tvTop = findViewById<TextView>(R.id.tvMoney)
        val btnMainMenu = findViewById<MaterialButton>(R.id.btnMainMenu)
        val btnMapDepot = findViewById<MaterialButton>(R.id.btnMapDepot)
        val btnGlobalDepot = findViewById<MaterialButton>(R.id.btnGlobalDepot)

        val cardForest = findViewById<MaterialCardView>(R.id.cardForest)
        val cardCoal = findViewById<MaterialCardView>(R.id.cardCoal)
        val cardIron = findViewById<MaterialCardView>(R.id.cardIron)

        fun refreshTop() {
            val money = moneyStore.getMoney()
            val stock = depotStore.getInventory(MapType.Madencilik).values.sum()
            tvTop.text = "💰 ${formatMoney(money)} ₺  |  📦 Stok: $stock  |  Maden/Orman"
        }

        btnMainMenu.setOnClickListener {
            startActivity(Intent(this, MainMenuActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
            finish()
        }
        btnMapDepot.setOnClickListener { showMapDepotDialog() }
        btnGlobalDepot.setOnClickListener { startActivity(Intent(this, GlobalDepotActivity::class.java)) }

        cardForest.setOnClickListener { mine("forest", 12, Product.ODUN, 2..5) }
        cardCoal.setOnClickListener { mine("coal", 15, Product.KOMUR, 1..4) }
        cardIron.setOnClickListener { mine("iron", 18, Product.DEMIR_CEVHER, 1..3) }

        refreshTop()
        updateCardTimes()

        ticker = object : Runnable {
            override fun run() {
                refreshTop()
                updateCardTimes()
                handler.postDelayed(this, 1000)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        ticker?.let { handler.post(it) }
    }

    override fun onPause() {
        super.onPause()
        ticker?.let { handler.removeCallbacks(it) }
    }

    private fun updateCardTimes() {
        setCooldownText("forest", 12, R.id.tvForestDesc)
        setCooldownText("coal", 15, R.id.tvCoalDesc)
        setCooldownText("iron", 18, R.id.tvIronDesc)
    }

    private fun setCooldownText(key: String, cooldownSec: Int, tvId: Int) {
        val tv = findViewById<TextView>(tvId)
        val now = System.currentTimeMillis()
        val last = miningStore.getLast("cd_$key")
        val left = max(0, cooldownSec - ((now - last) / 1000L).toInt())
        tv.text = if (left <= 0) "Hazır! Tıkla ve çıkar." else "Kalan süre: $left sn"
    }

    private fun mine(key: String, cooldownSec: Int, product: Product, qtyRange: IntRange) {
        val now = System.currentTimeMillis()
        val last = miningStore.getLast("cd_$key")
        val left = max(0, cooldownSec - ((now - last) / 1000L).toInt())
        if (left > 0) {
            toast("⏳ Bekle: $left sn")
            return
        }
        val qty = Random.nextInt(qtyRange.first, qtyRange.last + 1)
        depotStore.add(MapType.Madencilik, product, qty)
        miningStore.setLast("cd_$key", now)
        toast("✅ +$qty ${product.title}")
    }

    private fun formatMoney(v: Int): String {
        val s = v.toString()
        val sb = StringBuilder()
        for (i in s.indices) {
            sb.append(s[i])
            val left = s.length - i - 1
            if (left > 0 && left % 3 == 0) sb.append('.')
        }
        return sb.toString()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
