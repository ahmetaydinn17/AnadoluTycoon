package com.example.anadolutycoon

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class DepotStore(context: Context) {

    private val prefs = context.getSharedPreferences("depot_store", Context.MODE_PRIVATE)
    private val gson = Gson()

    private fun key(map: MapType) = "depot_${map.name}"

    fun getInventory(map: MapType): MutableMap<Product, Int> {
        val json = prefs.getString(key(map), null) ?: return mutableMapOf()
        return try {
            val type = object : TypeToken<MutableMap<Product, Int>>() {}.type
            gson.fromJson(json, type) ?: mutableMapOf()
        } catch (_: Exception) {
            mutableMapOf()
        }
    }

    private fun saveInventory(map: MapType, inv: Map<Product, Int>) {
        prefs.edit().putString(key(map), gson.toJson(inv)).apply()
    }

    fun add(map: MapType, product: Product, qty: Int) {
        val inv = getInventory(map)
        val addQty = qty.coerceAtLeast(0)
        inv[product] = (inv[product] ?: 0) + addQty
        saveInventory(map, inv)
    }

    fun remove(map: MapType, product: Product, qty: Int): Boolean {
        val inv = getInventory(map)
        val cur = inv[product] ?: 0
        if (cur < qty) return false
        val left = cur - qty
        if (left <= 0) inv.remove(product) else inv[product] = left
        saveInventory(map, inv)
        return true
    }
}
