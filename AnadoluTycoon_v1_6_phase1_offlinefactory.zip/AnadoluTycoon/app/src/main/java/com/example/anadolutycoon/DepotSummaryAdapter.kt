package com.example.anadolutycoon

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView

class DepotSummaryAdapter(
    private val context: Context,
    private val items: List<DepotSummaryRow>
) : BaseAdapter() {

    override fun getCount() = items.size
    override fun getItem(position: Int) = items[position]
    override fun getItemId(position: Int) = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val v = convertView ?: LayoutInflater.from(context).inflate(R.layout.item_depot_row, parent, false)
        val row = items[position]

        v.findViewById<TextView>(R.id.tvMapTitle).text = mapTitle(row.map)
        v.findViewById<TextView>(R.id.tvTotal).text = "Toplam: ${row.total}"
        v.findViewById<TextView>(R.id.tvTop).text = row.top3

        return v
    }

    private fun mapTitle(m: MapType): String {
        return when (m) {
            MapType.Ciftlik -> "Çiftlik"
            MapType.Koy -> "Köy"
            MapType.Sehir -> "Şehir"
            MapType.Madencilik -> "Madencilik"
            MapType.Hayvancilik -> "Hayvancılık"
            MapType.KucukOSB -> "Küçük OSB"
            MapType.OSB -> "OSB"
        }
    }
}
