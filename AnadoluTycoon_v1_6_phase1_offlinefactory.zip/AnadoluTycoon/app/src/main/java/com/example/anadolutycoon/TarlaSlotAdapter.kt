package com.example.anadolutycoon

import android.app.AlertDialog
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import kotlin.math.max
import kotlin.math.min
import androidx.core.content.ContextCompat


class TarlaSlotAdapter(
    private val items: List<TarlaSlot>,
    private val getMoney: () -> Int,
    private val getBoostPrice: (TarlaSlot, BoostType) -> Int,
    private val getGrowPrice: (TarlaSlot) -> Int,
    private val onUnlockClick: (TarlaSlot) -> Unit,
    private val onActionClick: (TarlaSlot) -> Unit, // ekim/hasat sadece BUTON
    private val onBoostPurchased: (TarlaSlot, BoostType) -> Unit,
    private val onGrowPurchased: (TarlaSlot) -> Unit,
) : RecyclerView.Adapter<TarlaSlotAdapter.VH>() {

    enum class BoostType { WORKER, WATER, FERTILIZER }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val cardRoot: MaterialCardView = v.findViewById(R.id.cardRoot)

        val tvLock: TextView = v.findViewById(R.id.tvLock)

        val tvAcreNumber: TextView = v.findViewById(R.id.tvAcreNumber)
        val tvAcreUnit: TextView = v.findViewById(R.id.tvAcreUnit)
        val tvYield: TextView = v.findViewById(R.id.tvYield)

        val imgPlot: ImageView = v.findViewById(R.id.imgPlot)

        val tvStatus: TextView = v.findViewById(R.id.tvStatus)
        val btnAction: MaterialButton = v.findViewById(R.id.btnAction)

        val progress: ProgressBar = v.findViewById(R.id.progress)

        val boostRow: View = v.findViewById(R.id.boostRow)
        val btnWorker: TextView = v.findViewById(R.id.btnWorker)
        val btnWater: TextView = v.findViewById(R.id.btnWater)
        val btnFertilizer: TextView = v.findViewById(R.id.btnFertilizer)
        val btnGrow: TextView = v.findViewById(R.id.btnGrow)

        val tvWorkerCount: TextView = v.findViewById(R.id.tvWorkerCount)
        val tvWaterCount: TextView = v.findViewById(R.id.tvWaterCount)
        val tvFertCount: TextView = v.findViewById(R.id.tvFertCount)

        val tvWorkerPrice: TextView = v.findViewById(R.id.tvWorkerPrice)
        val tvWaterPrice: TextView = v.findViewById(R.id.tvWaterPrice)
        val tvFertPrice: TextView = v.findViewById(R.id.tvFertPrice)
        val tvGrowPrice: TextView = v.findViewById(R.id.tvGrowPrice)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_tarla_slot, parent, false)
        return VH(v)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val s = items[position]

        // kart tıklaması KAPALI: her yere basınca ekim/hasat olmasın
        h.itemView.setOnClickListener(null)

        // Reset
        h.cardRoot.strokeWidth = 0

        // KİLİTLİ
        if (!s.isUnlocked) {
            h.tvLock.visibility = View.VISIBLE
            h.tvLock.text = "🔒 Kilitli - Aç: ${s.unlockPrice} TL"

            h.tvAcreNumber.visibility = View.GONE
            h.tvAcreUnit.visibility = View.GONE
            h.tvYield.visibility = View.GONE
            h.imgPlot.visibility = View.GONE
            h.tvStatus.visibility = View.GONE
            h.progress.visibility = View.GONE
            h.btnAction.visibility = View.GONE
            h.boostRow.visibility = View.GONE

            // sadece unlock için karta tık
            h.itemView.setOnClickListener { onUnlockClick(s) }
            return
        }

        // AÇIK
        h.tvLock.visibility = View.GONE
        h.tvAcreNumber.visibility = View.VISIBLE
        h.tvAcreUnit.visibility = View.VISIBLE
        h.tvYield.visibility = View.VISIBLE
        h.imgPlot.visibility = View.VISIBLE
        h.boostRow.visibility = View.VISIBLE

        val acres = max(5, s.acresOwned)
        h.tvAcreNumber.text = acres.toString()
        h.tvAcreUnit.text = "Dönüm"

        val isEmpty = (s.product == null)
        val isReady = (!isEmpty && s.phase == SlotPhase.READY)
        val isWorking = (!isEmpty && s.phase != SlotPhase.READY)

        // görsel
        when {
            isEmpty -> h.imgPlot.setImageResource(R.drawable.plot_empty)
            isReady -> h.imgPlot.setImageResource(R.drawable.plot_ready)
            else -> h.imgPlot.setImageResource(R.drawable.plot_growing)
        }

        // READY çerçeve
        if (isReady) {
            h.cardRoot.strokeWidth = dp(h.itemView, 2)
            h.cardRoot.strokeColor = 0xFF16A34A.toInt()
        }

        // Action butonu (Sadece BUTON)
        when {
            isEmpty -> {
                h.btnAction.visibility = View.VISIBLE
                h.btnAction.text = "Ekim"
                h.btnAction.setBackgroundColor(ContextCompat.getColor(h.itemView.context, R.color.yeşil))
                h.btnAction.setTextColor(ContextCompat.getColor(h.itemView.context, android.R.color.white))
                h.btnAction.setOnClickListener { onActionClick(s) }
            }
            isReady -> {
                h.btnAction.visibility = View.VISIBLE
                h.btnAction.text = "Hasat"
                h.btnAction.setBackgroundColor(ContextCompat.getColor(h.itemView.context, R.color.turuncu))
                h.btnAction.setTextColor(ContextCompat.getColor(h.itemView.context, android.R.color.white))
                h.btnAction.setOnClickListener { onActionClick(s) }
            }
            else -> {
                h.btnAction.visibility = View.GONE
                h.btnAction.setOnClickListener(null)

            }
        }

        // Status + progress
        when {
            isEmpty -> {
                h.tvStatus.visibility = View.GONE
                h.progress.visibility = View.GONE
            }
            isReady -> {
                val p = s.product!!
                h.tvStatus.visibility = View.VISIBLE
                h.tvStatus.text = "${p.emoji} ${p.title} • Hazır"
                h.progress.visibility = View.GONE
            }
            else -> {
                val p = s.product!!
                val (phaseName, percent, remainingText) = computeProgressTextScaled(s)
                h.tvStatus.visibility = View.VISIBLE
                h.tvStatus.text = "${p.emoji} ${p.title} • $phaseName: %$percent | $remainingText"
                h.progress.visibility = View.VISIBLE
                h.progress.max = 100
                h.progress.progress = percent
            }
        }

        // yield
        if (s.product != null) {
            val sizeFactor = 5f / acres.toFloat()
            val boostFactor =
                1f + (s.workerCount * 0.05f * sizeFactor) +
                        (s.irrigationLevel * 0.08f * sizeFactor) +
                        (s.fertilizerLevel * 0.10f * sizeFactor)

            val base = s.product!!.yieldPerAcre * acres
            val totalYield = (base * boostFactor).toInt().coerceAtLeast(0)
            h.tvYield.text = "Verim: $totalYield"
        } else {
            h.tvYield.text = "Verim: -"
        }

        // count
        h.tvWorkerCount.text = "x${s.workerCount}"
        h.tvWaterCount.text = "x${s.irrigationLevel}"
        h.tvFertCount.text = "x${s.fertilizerLevel}"

        // prices
        val money = getMoney()
        val workerPrice = getBoostPrice(s, BoostType.WORKER)
        val waterPrice = getBoostPrice(s, BoostType.WATER)
        val fertPrice = getBoostPrice(s, BoostType.FERTILIZER)
        val growPrice = getGrowPrice(s)

        h.tvWorkerPrice.text = "${workerPrice}₺"
        h.tvWaterPrice.text = "${waterPrice}₺"
        h.tvFertPrice.text = "${fertPrice}₺"
        h.tvGrowPrice.text = "${growPrice}₺"

        // boost sadece boşken alınır (işteyken gri)
        val canUseBoosts = isEmpty
        fun confirmBuy(title: String, price: Int, onOk: () -> Unit) {
            AlertDialog.Builder(h.itemView.context)
                .setTitle(title)
                .setMessage("$price₺ ödeyip satın alınsın mı?")
                .setPositiveButton("Satın Al") { _, _ -> onOk() }
                .setNegativeButton("İptal", null)
                .show()

        }

        if (!canUseBoosts) {
            applyState(h.btnWorker, false)
            applyState(h.btnWater, false)
            applyState(h.btnFertilizer, false)
            applyState(h.btnGrow, false)

            h.btnWorker.setOnClickListener(null)
            h.btnWater.setOnClickListener(null)
            h.btnFertilizer.setOnClickListener(null)
            h.btnGrow.setOnClickListener(null)
        } else {
            applyState(h.btnWorker, money >= workerPrice)
            applyState(h.btnWater, money >= waterPrice)
            applyState(h.btnFertilizer, money >= fertPrice)
            applyState(h.btnGrow, money >= growPrice)

            h.btnWorker.setOnClickListener {
                if (money >= workerPrice) {
                    confirmBuy("👷 İşçi (+%5)", workerPrice) { onBoostPurchased(s, BoostType.WORKER) }
                }
            }
            h.btnWater.setOnClickListener {
                if (money >= waterPrice) {
                    confirmBuy("💧 Sulama (+%8)", waterPrice) { onBoostPurchased(s, BoostType.WATER) }
                }
            }
            h.btnFertilizer.setOnClickListener {
                if (money >= fertPrice) {
                    confirmBuy("🧪 Gübre (+%10)", fertPrice) { onBoostPurchased(s, BoostType.FERTILIZER) }
                }
            }
            h.btnGrow.setOnClickListener {
                if (money >= growPrice) {
                    confirmBuy("⬆️ Tarla büyüt", growPrice) { onGrowPurchased(s) }
                }
            }
        }
    }

    private fun applyState(v: View, enabled: Boolean) {
        v.isEnabled = enabled
        v.alpha = if (enabled) 1.0f else 0.35f
    }

    private fun computeProgressTextScaled(s: TarlaSlot): Triple<String, Int, String> {
        val p = s.product ?: return Triple("Hazır", 100, "0s")

        val acres = max(5, s.acresOwned)
        val scale = acres / 5f

        val now = System.currentTimeMillis()
        val elapsedSec = ((now - s.phaseStartedAt) / 1000).toInt().coerceAtLeast(0)

        val totalBase = when (s.phase) {
            SlotPhase.PLANTED -> p.plantSeconds
            SlotPhase.GROWING -> p.growSeconds
            SlotPhase.HARVESTING -> p.harvestSeconds
            else -> 0
        }
        val totalSec = (totalBase * scale).toInt().coerceAtLeast(1)

        val (name, percent) = when (s.phase) {
            SlotPhase.PLANTED -> "Ekiliyor" to calcPercent(elapsedSec, totalSec)
            SlotPhase.GROWING -> "Büyüyor" to calcPercent(elapsedSec, totalSec)
            SlotPhase.HARVESTING -> "Hasat" to calcPercent(elapsedSec, totalSec)
            else -> "Hazır" to 100
        }

        val remaining = max(0, totalSec - elapsedSec)
        return Triple(name, percent, "${remaining}s")
    }

    private fun calcPercent(elapsed: Int, total: Int): Int {
        val v = (elapsed * 100f / total.toFloat()).toInt()
        return min(100, max(0, v))
    }

    private fun dp(view: View, dp: Int): Int {
        return (dp * view.resources.displayMetrics.density).toInt()
    }
}
