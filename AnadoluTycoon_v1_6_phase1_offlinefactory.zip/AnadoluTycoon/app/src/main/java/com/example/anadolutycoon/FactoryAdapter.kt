package com.example.anadolutycoon

import android.app.AlertDialog
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import kotlin.math.max
import kotlin.math.min

class FactoryAdapter(
    private val context: Context,
    private val factories: List<Factory>,
    private val depotStore: DepotStore,
    private val moneyStore: GlobalMoneyStore,
    private val mapType: MapType
) : RecyclerView.Adapter<FactoryAdapter.VH>() {

    // ✅ Offline/Restart için fabrika state'i kalıcı tut
    private val stateStore = FactoryStateStore(context)

    init {
        // adapter her yaratıldığında kaydedilmiş state'leri yükle
        for (f in factories) {
            val st = stateStore.load(mapType, f.id)
            if (st != null) {
                // bozuk/eksik state gelirse güvenli şekilde temizle
                if (st.isWorking && (st.totalSeconds <= 0 || st.startedAt <= 0L || st.plannedCount <= 0)) {
                    stateStore.clear(mapType, f.id)
                } else {
                    f.isWorking = st.isWorking
                    f.startedAt = st.startedAt
                    f.totalSeconds = st.totalSeconds
                    f.plannedCount = st.plannedCount
                }
            }
        }
    }
    // ✅ Progress için tick: RecyclerView re-bind olmadıkça % ilerlemez, bu yüzden periyodik refresh yapıyoruz
    private val uiHandler = Handler(Looper.getMainLooper())
    private val tickRunnable = object : Runnable {
        override fun run() {
            var anyWorking = false
            for (i in factories.indices) {
                if (factories[i].isWorking) {
                    anyWorking = true
                    // bu item yeniden bind edilince progress + bitiş kontrolü çalışır
                    notifyItemChanged(i)
                }
            }
            uiHandler.postDelayed(this, if (anyWorking) 500L else 1200L)
        }
    }

    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        super.onAttachedToRecyclerView(recyclerView)
        uiHandler.removeCallbacks(tickRunnable)
        uiHandler.post(tickRunnable)
    }

    override fun onDetachedFromRecyclerView(recyclerView: RecyclerView) {
        uiHandler.removeCallbacks(tickRunnable)
        super.onDetachedFromRecyclerView(recyclerView)
    }


    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvTitle: TextView = v.findViewById(R.id.tvTitle)
        val tvRecipe: TextView = v.findViewById(R.id.tvRecipe)

        val imgFactory: android.widget.ImageView = v.findViewById(R.id.imgFactory)
        val tvStatus: TextView = v.findViewById(R.id.tvStatus)
        val progress: android.widget.ProgressBar = v.findViewById(R.id.progress)

        val btnAction: MaterialButton = v.findViewById(R.id.btnAction)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_factory_card, parent, false)
        return VH(v)
    }

    override fun getItemCount() = factories.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val f = factories[position]

        h.tvTitle.text = "${f.icon} ${f.name}"
        h.tvRecipe.text = "Girdi: ${f.inputQty}x ${f.input.emoji} ${f.input.title} → Çıktı: ${f.outputQty}x ${f.output.emoji} ${f.output.title}"

        val now = System.currentTimeMillis()

        // ✅ ÇALIŞIYORSA progress güncelle
        if (f.isWorking) {
            val elapsedSec = ((now - f.startedAt) / 1000L).toInt().coerceAtLeast(0)
            val total = max(1, f.totalSeconds)
            val percent = (elapsedSec * 100f / total).toInt().coerceIn(0, 100)
            val remaining = max(0, total - elapsedSec)

            h.progress.visibility = View.VISIBLE
            h.progress.max = 100
            h.progress.progress = percent

            h.tvStatus.text = "Durum: Çalışıyor • %$percent | ${remaining}s"
            h.btnAction.isEnabled = false
            h.btnAction.alpha = 0.5f

            // görsel
            h.imgFactory.setImageResource(R.drawable.factory_working)

            // ✅ BİTTİ Mİ?
            if (elapsedSec >= total) {
                // üretimi bitir
                f.isWorking = false

                // çıktı ekle
                val produced = f.plannedCount * f.outputQty
                depotStore.add(mapType, f.output, produced)

                // UI
                h.progress.visibility = View.GONE
                h.tvStatus.text = "Durum: Tamamlandı (+$produced ${f.output.title})"
                h.btnAction.isEnabled = true
                h.btnAction.alpha = 1f
                h.btnAction.text = "Üret"
                h.imgFactory.setImageResource(R.drawable.factory_done)

                Toast.makeText(context, "✅ $produced adet ${f.output.title} üretildi", Toast.LENGTH_SHORT).show()

                // ✅ state temizle (offline için)
                stateStore.clear(mapType, f.id)
            }

        } else {
            // ✅ BOŞTA
            h.progress.visibility = View.GONE
            h.tvStatus.text = "Durum: Boşta"
            h.btnAction.isEnabled = true
            h.btnAction.alpha = 1f
            h.btnAction.text = "Üret"
            h.imgFactory.setImageResource(R.drawable.factory_idle)
        }

        // ✅ ÜRET butonu -> kullanıcı qty seçsin (kayar + tümü)
        h.btnAction.setOnClickListener {
            if (f.isWorking) return@setOnClickListener
            showQtyDialog(f, position)
        }
    }

    private fun showQtyDialog(f: Factory, position: Int) {
        val inv = depotStore.getInventory(mapType)
        val stock = inv[f.input] ?: 0

        if (stock <= 0) {
            toast("Depoda ${f.input.title} yok")
            return
        }

        // Max üretim sayısı: stok / inputQty
        val maxCount = (stock / max(1, f.inputQty)).coerceAtLeast(1)

        val v = LayoutInflater.from(context).inflate(R.layout.dialog_qty_factory, null)

        val tvTitle = v.findViewById<TextView>(R.id.tvTitle)
        val tvNeed = v.findViewById<TextView>(R.id.tvNeed)
        val tvTime = v.findViewById<TextView>(R.id.tvTime)
        val tvQty = v.findViewById<TextView>(R.id.tvQty)

        val seek = v.findViewById<SeekBar>(R.id.seekQty)

        val btnOk = v.findViewById<MaterialButton>(R.id.btnOk)
        val btnAll = v.findViewById<MaterialButton>(R.id.btnAll)

        tvTitle.text = "${f.icon} ${f.name}"
        seek.max = max(0, maxCount - 1)
        seek.progress = 0

        var qty = 1
        fun refresh() {
            val needInput = qty * f.inputQty
            val outQty = qty * f.outputQty
            val totalSec = qty * f.workSeconds
            tvQty.text = "Adet: $qty"
            tvNeed.text = "Girdi: $needInput ${f.input.title} | Çıktı: $outQty ${f.output.title}"
            tvTime.text = "Süre: ${totalSec}s"
        }
        refresh()

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                qty = progress + 1
                refresh()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        val dlg = AlertDialog.Builder(context)
            .setView(v)
            .setNegativeButton("İptal", null)
            .create()

        btnOk.setOnClickListener {
            startProduction(f, qty, position)
            dlg.dismiss()
        }

        btnAll.setOnClickListener {
            startProduction(f, maxCount, position)
            dlg.dismiss()
        }

        dlg.show()
    }

    private fun startProduction(f: Factory, qty: Int, position: Int) {
        val inv = depotStore.getInventory(mapType)
        val stock = inv[f.input] ?: 0

        val needInput = qty * f.inputQty
        if (stock < needInput) {
            toast("Yetersiz ${f.input.title} (Gerekli: $needInput)")
            return
        }

        // girdiyi düş
        val ok = depotStore.remove(mapType, f.input, needInput)
        if (!ok) {
            toast("Yetersiz stok!")
            return
        }

        // ✅ süre = qty × bazSüre
        f.isWorking = true
        f.startedAt = System.currentTimeMillis()
        f.plannedCount = qty
        f.totalSeconds = qty * f.workSeconds

        // ✅ offline için kaydet
        stateStore.save(
            mapType,
            f.id,
            FactoryStateStore.State(
                isWorking = true,
                startedAt = f.startedAt,
                totalSeconds = f.totalSeconds,
                plannedCount = f.plannedCount
            )
        )

        notifyItemChanged(position)
        toast("🏭 Üretim başladı ($qty adet) • ${f.totalSeconds}s")
    }

    private fun toast(msg: String) =
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
}
