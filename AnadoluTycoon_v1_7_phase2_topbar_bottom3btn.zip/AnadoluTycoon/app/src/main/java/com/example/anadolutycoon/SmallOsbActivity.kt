package com.example.anadolutycoon

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.ListView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import kotlin.math.max
import kotlin.random.Random

class SmallOsbActivity : AppCompatActivity() {

    private lateinit var depotStore: DepotStore
    private lateinit var moneyStore: GlobalMoneyStore

    // piyasaya benzer fiyat istersek kullanırız (şimdilik sabit baseSellPrice)
    private val marketPrices = mutableMapOf<Product, Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_small_osb)

        depotStore = DepotStore(this)
        moneyStore = GlobalMoneyStore(this)

        val tvTop = findViewById<TextView>(R.id.tvMoney)
        val rv = findViewById<RecyclerView>(R.id.rvFactories)

        val btnMainMenu = findViewById<MaterialButton>(R.id.btnMainMenu)
        val btnMapDepot = findViewById<MaterialButton>(R.id.btnMapDepot)
        btnMapDepot.text = "K. OSB Depo"val btnGlobalDepot = findViewById<MaterialButton>(R.id.btnGlobalDepot)

        fun refreshTop() {
    val money = moneyStore.getMoney()
    val stock = depotStore.getInventory(MapType.KucukOSB).values.sum()
    tvTop.text = UiBars.topBarText(money, stock, "Küçük OSB")
}

        btnMainMenu.setOnClickListener { finish() }

        btnGlobalDepot.setOnClickListener {
            startActivity(Intent(this, GlobalDepotActivity::class.java))
        }

        // ✅ K.OSB Depo: satış + gönder
        btnMapDepot.setOnClickListener {
            showOsbDepotDialog()
        }

        // Fabrika listesi (sen zaten ayarladın)
        val factories = listOf(
            Factory(
                id = "salca",
                icon = "🥫",
                name = "Salça Fabrikası",
                input = Product.DOMATES,
                inputQty = 3,
                output = Product.SALCA,
                outputQty = 1,
                workSeconds = 10
            ),
            Factory(
                id = "un",
                icon = "🌾",
                name = "Un Fabrikası",
                input = Product.BUGDAY,
                inputQty = 2,
                output = Product.UN,
                outputQty = 1,
                workSeconds = 8
            ),
            Factory(
                id = "recel",
                icon = "🍓",
                name = "Reçel Fabrikası",
                input = Product.CILEK,
                inputQty = 4,
                output = Product.RECEL,
                outputQty = 1,
                workSeconds = 12
            ),
            Factory(
                id = "yem",
                icon = "🧃",
                name = "Yem Fabrikası",
                input = Product.BUGDAY,
                inputQty = 3,
                output = Product.YEM,
                outputQty = 1,
                workSeconds = 10
            ),
            Factory(
                id = "kurutma",
                icon = "🥭",
                name = "Kurutma Fabrikası",
                input = Product.DOMATES,
                inputQty = 5,
                output = Product.KURUT_DOMATES,
                outputQty = 1,
                workSeconds = 14
            )
        )

        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = FactoryAdapter(
            context = this,
            factories = factories,
            depotStore = depotStore,
            moneyStore = moneyStore,
            mapType = MapType.KucukOSB
        )

        refreshTop()
    }

    // =========================
    // K.OSB DEPO -> Ürün seç -> Trade dialog
    // =========================
    private fun showOsbDepotDialog() {
        val inv = depotStore.getInventory(MapType.KucukOSB)
        val products = inv.entries.filter { it.value > 0 }.map { it.key }

        if (products.isEmpty()) {
            toast("K. OSB deposu boş")
            return
        }

        val names = products.map { p ->
            "${p.emoji} ${p.title} (Stok: ${inv[p] ?: 0})"
        }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("K. OSB Depo")
            .setItems(names) { _, index ->
                val p = products[index]
                val stock = inv[p] ?: 0
                showTradeDialog(p, stock)
            }
            .setNegativeButton("Kapat", null)
            .show()
    }

    // =========================
    // Trade: Satış + Gönder (seekbar)
    // Aynı mantık FarmActivity ile aynı
    // =========================
    private fun showTradeDialog(product: Product, stock: Int) {
        if (stock <= 0) return

        val view = layoutInflater.inflate(R.layout.dialog_trade_product, null)

        val tvTitle = view.findViewById<TextView>(R.id.tvTradeTitle)
        val tvSinglePrice = view.findViewById<TextView>(R.id.tvSinglePrice)
        val tvBulkPrice = view.findViewById<TextView>(R.id.tvBulkPrice)

        val seek = view.findViewById<SeekBar>(R.id.seekQty)
        val tvQty = view.findViewById<TextView>(R.id.tvQty)

        val btnSellQty = view.findViewById<MaterialButton>(R.id.btnSellQty)
        val btnSellAll = view.findViewById<MaterialButton>(R.id.btnSellAll)
        val btnSendQty = view.findViewById<MaterialButton>(R.id.btnSendQty)
        val btnSendAll = view.findViewById<MaterialButton>(R.id.btnSendAll)

        val single = unitPrice(product)
        val bulk = bulkUnitPrice(product)

        tvTitle.text = "${product.emoji} ${product.title} • Stok: $stock"
        tvSinglePrice.text = "Tekli: ${single}₺"
        tvBulkPrice.text = "Çoklu(100+): ${bulk}₺"

        seek.max = max(0, stock - 1)
        seek.progress = 0

        var qty = 1
        tvQty.text = "Adet: $qty"

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                qty = progress + 1
                tvQty.text = "Adet: $qty"
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        val dlg = AlertDialog.Builder(this)
            .setView(view)
            .setNegativeButton("Kapat", null)
            .create()

        // ✅ SAT
        btnSellQty.setOnClickListener {
            val ok = depotStore.remove(MapType.KucukOSB, product, qty)
            if (!ok) {
                toast("Yetersiz stok!")
                return@setOnClickListener
            }

            val pricePer = if (qty >= 100) bulkUnitPrice(product) else unitPrice(product)
            val earn = pricePer * qty

            addMoney(earn)
            dlg.dismiss()
            toast("✅ Satıldı: +${earn}₺")
        }

        // ✅ TÜMÜ SAT
        btnSellAll.setOnClickListener {
            val cur = depotStore.getInventory(MapType.KucukOSB)[product] ?: 0
            if (cur <= 0) return@setOnClickListener

            val ok = depotStore.remove(MapType.KucukOSB, product, cur)
            if (!ok) {
                toast("Yetersiz stok!")
                return@setOnClickListener
            }

            val pricePer = if (cur >= 100) bulkUnitPrice(product) else unitPrice(product)
            val earn = pricePer * cur

            addMoney(earn)
            dlg.dismiss()
            toast("✅ Tümü satıldı: +${earn}₺")
        }

        // ✅ GÖNDER
        btnSendQty.setOnClickListener {
            pickSendTarget { target ->
                val ok = depotStore.remove(MapType.KucukOSB, product, qty)
                if (!ok) {
                    toast("Yetersiz stok!")
                    return@pickSendTarget
                }
                depotStore.add(target, product, qty)
                dlg.dismiss()
                toast("📦 Gönderildi: $qty adet → ${target.name}")
            }
        }

        // ✅ TÜMÜ GÖNDER
        btnSendAll.setOnClickListener {
            pickSendTarget { target ->
                val cur = depotStore.getInventory(MapType.KucukOSB)[product] ?: 0
                if (cur <= 0) return@pickSendTarget

                val ok = depotStore.remove(MapType.KucukOSB, product, cur)
                if (!ok) {
                    toast("Yetersiz stok!")
                    return@pickSendTarget
                }
                depotStore.add(target, product, cur)
                dlg.dismiss()
                toast("📦 Tümü gönderildi: $cur adet → ${target.name}")
            }
        }

        dlg.show()
    }

    private fun pickSendTarget(onPicked: (MapType) -> Unit) {
        // K.OSB’den nereye gitsin?
        val targets = listOf(
            MapType.Ciftlik,
            MapType.Koy,
            MapType.Sehir,
            MapType.OSB,
            MapType.Hayvancilik,
            MapType.Madencilik
        )
        val names = targets.map { it.name }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Nereye gönderilsin?")
            .setItems(names) { _, idx -> onPicked(targets[idx]) }
            .setNegativeButton("İptal", null)
            .show()
    }

    // ✅ fiyat: şimdilik baseSellPrice (istersen şehirde çarpanlı yapacağız)
    private fun unitPrice(p: Product): Int = p.baseSellPrice
    private fun bulkUnitPrice(p: Product): Int = max(1, (unitPrice(p) * 0.95f).toInt())

    private fun addMoney(amount: Int) {
        val cur = moneyStore.getMoney()
        moneyStore.setMoney(cur + max(0, amount))
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
