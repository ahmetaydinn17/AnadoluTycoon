package com.example.anadolutycoon

import android.widget.TextView

object UiBars {
    fun formatMoneyTl(value: Int): String {
        val s = value.toString()
        val sb = StringBuilder()
        for (i in s.indices) {
            if (i > 0 && (s.length - i) % 3 == 0) sb.append('.')
            sb.append(s[i])
        }
        return sb.toString()
    }

    fun topBarText(money: Int, stock: Int, mapTitle: String): String {
        return "Para: ${formatMoneyTl(money)} TL | Stok: $stock | $mapTitle"
    }

    fun setTopBar(tv: TextView, money: Int, stock: Int, mapTitle: String) {
        tv.text = topBarText(money, stock, mapTitle)
    }
}
