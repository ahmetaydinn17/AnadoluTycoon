package com.example.anadolutycoon

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import kotlin.math.min

class LivestockActivity : AppCompatActivity() {

    private lateinit var depotStore: DepotStore
    private lateinit var moneyStore: GlobalMoneyStore
    private lateinit var livestockStore: LivestockStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_livestock)

        depotStore = DepotStore(this)
        moneyStore = GlobalMoneyStore(this)
        livestockStore = LivestockStore(this)

        val tvTop = findViewById<TextView>(R.id.tvMoney)
        val btnMainMenu = findViewById<MaterialButton>(R.id.btnMainMenu)
        val btnGlobalDepot = findViewById<MaterialButton>(R.id.btnGlobalDepot)
        val btnMapDepot = findViewById<MaterialButton>(R.id.btnMapDepot)

        val cardChicken = findViewById<MaterialCardView>(R.id.cardChicken)
        val cardCow = findViewById<MaterialCardView>(R.id.cardCow)

        btnMainMenu.setOnClickListener { finish() }
        btnGlobalDepot.setOnClickListener { startActivity(Intent(this, GlobalDepotActivity::class.java)) }

        
        btnMapDepot.text = "Hayvancılık Depo"
        btnMapDepot.setOnClickListener { showDepotDialog() }
cardChicken.setOnClickListener { showChickenDialog() }
        cardCow.setOnClickListener { showCowDialog() }

        refreshTop(tvTop)
        refreshCards()
    }

    override fun onResume() {
        super.onResume()
        refreshTop(findViewById(R.id.tvMoney))
        refreshCards()
    }

    private fun refreshTop(tvTop: TextView) {
        val money = moneyStore.getMoney()
        val stock = depotStore.getInventory(MapType.Hayvancilik).values.sum()
        tvTop.text = UiBars.topBarText(money, stock, "Hayvancılık")
    }

    private fun refreshCards() {
        val chickens = livestockStore.getChickens()
        val cows = livestockStore.getCows()

        val tvChickenTitle = findViewById<TextView>(R.id.tvChickenTitle)
        val tvChickenDesc = findViewById<TextView>(R.id.tvChickenDesc)
        val tvCowTitle = findViewById<TextView>(R.id.tvCowTitle)
        val tvCowDesc = findViewById<TextView>(R.id.tvCowDesc)

        tvChickenTitle.text = "Kümes • Tavuk: $chickens"
        tvCowTitle.text = "Ahır • İnek: $cows"

        val eggsReady = calcReadyEggs()
        val milkReady = calcReadyMilk()

        tvChickenDesc.text = "Üretim: 1 tavuk / 30sn → 1 yumurta\nHazır: $eggsReady 🥚"
        tvCowDesc.text = "Üretim: 1 inek / 45sn → 1 süt\nHazır: $milkReady 🥛"
    }

    private fun showChickenDialog() {
        val buyCost = 250
        val chickens = livestockStore.getChickens()
        val ready = calcReadyEggs()

        AlertDialog.Builder(this)
            .setTitle("Kümes")
            .setMessage("Tavuk: $chickens\nHazır yumurta: $ready\n\nYeni tavuk: ${formatMoney(buyCost)}₺")
            .setPositiveButton("Yumurta Topla") { _, _ -> collectEggs() }
            .setNeutralButton("Tavuk Satın Al") { _, _ ->
                val money = moneyStore.getMoney()
                if (money < buyCost) {
                    toast("Yetersiz para")
                    return@setNeutralButton
                }
                moneyStore.setMoney(money - buyCost)
                livestockStore.setChickens(chickens + 1)
                refreshTop(findViewById(R.id.tvMoney))
                refreshCards()
                toast("✅ Tavuk alındı")
            }
            .setNegativeButton("Kapat", null)
            .show()
    }

    private fun showCowDialog() {
        val buyCost = 800
        val cows = livestockStore.getCows()
        val ready = calcReadyMilk()

        AlertDialog.Builder(this)
            .setTitle("Ahır")
            .setMessage("İnek: $cows\nHazır süt: $ready\n\nYeni inek: ${formatMoney(buyCost)}₺")
            .setPositiveButton("Süt Topla") { _, _ -> collectMilk() }
            .setNeutralButton("İnek Satın Al") { _, _ ->
                val money = moneyStore.getMoney()
                if (money < buyCost) {
                    toast("Yetersiz para")
                    return@setNeutralButton
                }
                moneyStore.setMoney(money - buyCost)
                livestockStore.setCows(cows + 1)
                refreshTop(findViewById(R.id.tvMoney))
                refreshCards()
                toast("✅ İnek alındı")
            }
            .setNegativeButton("Kapat", null)
            .show()
    }

    private fun calcReadyEggs(): Int {
        val chickens = livestockStore.getChickens()
        if (chickens <= 0) return 0
        val now = System.currentTimeMillis()
        val last = livestockStore.getLastCollectEgg()
        val elapsedSec = ((now - last) / 1000L).toInt().coerceAtLeast(0)
        val per = 30
        val produced = (elapsedSec / per) * chickens
        return min(500, produced)
    }

    private fun calcReadyMilk(): Int {
        val cows = livestockStore.getCows()
        if (cows <= 0) return 0
        val now = System.currentTimeMillis()
        val last = livestockStore.getLastCollectMilk()
        val elapsedSec = ((now - last) / 1000L).toInt().coerceAtLeast(0)
        val per = 45
        val produced = (elapsedSec / per) * cows
        return min(500, produced)
    }

    private fun collectEggs() {
        val ready = calcReadyEggs()
        if (ready <= 0) {
            toast("Henüz hazır değil")
            return
        }
        depotStore.add(MapType.Hayvancilik, Product.YUMURTA, ready)
        livestockStore.setLastCollectEgg(System.currentTimeMillis())
        refreshTop(findViewById(R.id.tvMoney))
        refreshCards()
        toast("✅ +$ready Yumurta")
    }

    private fun collectMilk() {
        val ready = calcReadyMilk()
        if (ready <= 0) {
            toast("Henüz hazır değil")
            return
        }
        depotStore.add(MapType.Hayvancilik, Product.SUT, ready)
        livestockStore.setLastCollectMilk(System.currentTimeMillis())
        refreshTop(findViewById(R.id.tvMoney))
        refreshCards()
        toast("✅ +$ready Süt")
    }

    private fun formatMoney(v: Int): String {
        val s = v.toString()
        val sb = StringBuilder()
        for (i in s.indices) {
            sb.append(s[i])
            val left = s.length - i - 1
            if (left > 0 && left % 3 == 0) sb.append('.')
        }
        return sb.toString()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }


private fun showDepotDialog() {
    val inv = depotStore.getInventory(MapType.Hayvancilik)
    val items = inv.entries.filter { it.value > 0 }.map { it.key }
    if (items.isEmpty()) {
        toast("Hayvancılık deposu boş")
        return
    }
    val arr = items.map { p -> "${p.emoji} ${p.title} • ${inv[p] ?: 0}" }.toTypedArray()
    android.app.AlertDialog.Builder(this)
        .setTitle("Hayvancılık Deposu")
        .setItems(arr, null)
        .setPositiveButton("Kapat", null)
        .show()
}
}
