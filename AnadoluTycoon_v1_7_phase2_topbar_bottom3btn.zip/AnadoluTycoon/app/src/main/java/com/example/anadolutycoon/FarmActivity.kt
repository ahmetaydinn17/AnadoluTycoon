package com.example.anadolutycoon

import android.app.AlertDialog
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ListView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import kotlin.math.max
import kotlin.random.Random
import android.content.Intent


// ✅ MarketListAdapter "List<MarketRow>" bekliyorsa bu class AYNEN böyle kalsın


class FarmActivity : AppCompatActivity() {

    private lateinit var storage: FarmStorage
    private lateinit var moneyStore: GlobalMoneyStore
    private lateinit var depotStore: DepotStore

    private lateinit var tvTop: TextView
    private lateinit var rv: RecyclerView
    private lateinit var adapter: TarlaSlotAdapter

    private lateinit var btnMainMenu: MaterialButton
    private lateinit var btnDepot: MaterialButton
    private lateinit var btnGlobalDepot: MaterialButton
    private lateinit var btnMapDepot: MaterialButton



    // State
    private val slots = mutableListOf<TarlaSlot>()
    private val marketPrices = mutableMapOf<Product, Int>() // TEK satış fiyatı
    private var nextMarketUpdateAt: Long = 0L

    private val uiHandler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            updateSlotsProgress()
            ensureMarketUpToDate()
            adapter.notifyDataSetChanged()
            refreshTop()
            uiHandler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btnMainMenu = findViewById(R.id.btnMainMenu)
        btnMapDepot = findViewById(R.id.btnMapDepot)
        btnGlobalDepot = findViewById(R.id.btnGlobalDepot)

        btnMainMenu.setOnClickListener {
            finish()
        }

        btnMapDepot.setOnClickListener { showFarmDepotDialog() }

        btnGlobalDepot.setOnClickListener {
            startActivity(Intent(this, GlobalDepotActivity::class.java))
        }





        storage = FarmStorage(this)
        moneyStore = GlobalMoneyStore(this)
        depotStore = DepotStore(this)

        tvTop = findViewById(R.id.tvMoney)
        rv = findViewById(R.id.rvSlots)


        rv.layoutManager = GridLayoutManager(this, 2)
        rv.addItemDecoration(GridSpacingItemDecoration(2, dp(10)))

        loadOrInit()

        adapter = TarlaSlotAdapter(
            items = slots,
            getMoney = { moneyStore.getMoney() },
            getBoostPrice = { slot, type -> boostPrice(slot, type) },
            getGrowPrice = { slot -> growPrice(slot) },
            onUnlockClick = { slot -> confirmUnlock(slot) },
            onActionClick = { slot -> onAction(slot) },
            onBoostPurchased = { slot, type -> onBoostPurchased(slot, type) },
            onGrowPurchased = { slot -> onGrowPurchased(slot) }
        )
        rv.adapter = adapter


        refreshTop()
        uiHandler.post(tick)
    }

    override fun onDestroy() {
        uiHandler.removeCallbacks(tick)
        super.onDestroy()
    }

    // ----------------------------
    // LOAD / SAVE
    // ----------------------------
    private fun loadOrInit() {
        val loaded = storage.load()
        if (loaded != null) {
            slots.clear()
            slots.addAll(loaded.slots)

            marketPrices.clear()
            marketPrices.putAll(loaded.marketPrices)

            nextMarketUpdateAt = loaded.nextMarketUpdateAt
            ensureMarketUpToDate()
            return
        }

        // İlk kurulum
        slots.clear()

        for (i in 1..16) {
            slots.add(
                TarlaSlot(
                    id = i,
                    isUnlocked = (i == 1), // sadece 1 açık başlasın
                    acresOwned = if (i == 1) 5 else 0,
                    unlockPrice = 4000 + (i * 3500),
                    acrePrice = 200 + (i * 25)
                )
            )
        }


        seedMarketPrices()
        nextMarketUpdateAt = System.currentTimeMillis() + MARKET_PERIOD_MS

        if (moneyStore.getMoney() <= 0) moneyStore.setMoney(999999)

        save()
    }

    private fun save() {
        storage.save(
            FarmState(
                money = moneyStore.getMoney(),
                inventory = emptyMap(),
                slots = slots,
                marketPrices = marketPrices,
                nextMarketUpdateAt = nextMarketUpdateAt
            )
        )
    }

    private fun saveAndRefresh() {
        save()
        adapter.notifyDataSetChanged()
        refreshTop()
    }

    // ----------------------------
    // TOP UI
    // ----------------------------
    private fun refreshTop() {
    val money = moneyStore.getMoney()
    val stock = depotStore.getInventory(MapType.Ciftlik).values.sum()
    tvTop.text = UiBars.topBarText(money, stock, "Çiftlik")
}

    // ----------------------------
    // TARLA FAZ İLERLETME
    // ----------------------------
    private fun updateSlotsProgress() {
        val now = System.currentTimeMillis()
        for (s in slots) {
            val p = s.product ?: continue

            when (s.phase) {
                SlotPhase.PLANTED -> {
                    val elapsed = now - s.phaseStartedAt
                    if (elapsed >= p.plantSeconds * 1000L) {
                        s.phase = SlotPhase.GROWING
                        s.phaseStartedAt = now
                        save()
                    }
                }
                SlotPhase.GROWING -> {
                    val elapsed = now - s.phaseStartedAt
                    if (elapsed >= p.growSeconds * 1000L) {
                        s.phase = SlotPhase.HARVESTING
                        s.phaseStartedAt = now
                        save()
                    }
                }
                SlotPhase.HARVESTING -> {
                    val elapsed = now - s.phaseStartedAt
                    if (elapsed >= p.harvestSeconds * 1000L) {
                        s.phase = SlotPhase.READY
                        save()
                    }
                }
                else -> Unit
            }
        }
    }

    // ----------------------------
    // MARKET (değişken)
    // ----------------------------
    private fun ensureMarketUpToDate() {
        val now = System.currentTimeMillis()
        if (now < nextMarketUpdateAt) return

        for (p in Product.values()) {
            val base = p.baseSellPrice
            val delta = (base * 0.20f).toInt()
            val newPrice = (base + Random.nextInt(-delta, delta + 1)).coerceAtLeast(1)
            marketPrices[p] = newPrice
        }

        nextMarketUpdateAt = now + MARKET_PERIOD_MS
        save()
    }

    private fun seedMarketPrices() {
        for (p in Product.values()) marketPrices[p] = p.baseSellPrice
    }

    private fun bulkUnitPrice(p: Product): Int = max(1, (unitPrice(p) * 0.95f).toInt())

    private fun marketRemainingSec(): Long {
        val now = System.currentTimeMillis()
        return max(0L, (nextMarketUpdateAt - now) / 1000L)
    }

    // ----------------------------
    // DIALOG: PİYASALAR
    // ----------------------------
    private fun showMarketDialog() {
        ensureMarketUpToDate()

        val v = layoutInflater.inflate(R.layout.dialog_market, null)
        val lv = v.findViewById<ListView>(R.id.lvMarket)
        val btnClose = v.findViewById<TextView>(R.id.btnClose)

        val rows: List<MarketRow> = Product.values().map { p ->
            MarketRow(p, unitPrice(p), bulkUnitPrice(p))
        }

        // ✅ MarketListAdapter senin dosyan
        lv.adapter = MarketListAdapter(this, rows)

        val dlg = AlertDialog.Builder(this)
            .setTitle("Piyasalar (Güncellenme: ${marketRemainingSec()}s)")
            .setView(v)
            .create()

        btnClose.setOnClickListener { dlg.dismiss() }
        dlg.show()
    }

    // ----------------------------
    // DIALOG: ÜRÜNLER (Satış + Gönder)
    // ----------------------------
    private fun showSellDialog() {
        val inv = depotStore.getInventory(MapType.Ciftlik)
        val products = inv.entries.filter { it.value > 0 }.map { it.key }

        if (products.isEmpty()) {
            toast("Depo boş")
            return
        }

        val names = products.map { p ->
            "${p.emoji} ${p.title} (Stok: ${inv[p] ?: 0})"
        }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Ürünler / Depo")
            .setItems(names) { _, index ->
                val p = products[index]
                val stock = inv[p] ?: 0
                showTradeDialog(p, stock)
            }
            .setNegativeButton("Kapat", null)
            .show()
    }

    private fun showTradeDialog(product: Product, stock: Int) {
        if (stock <= 0) return

        val view = layoutInflater.inflate(R.layout.dialog_trade_product, null)

        // ✅ ID’LER XML’İNLE AYNI
        val tvTitle = view.findViewById<TextView>(R.id.tvTradeTitle)
        val tvSinglePrice = view.findViewById<TextView>(R.id.tvSinglePrice)
        val tvBulkPrice = view.findViewById<TextView>(R.id.tvBulkPrice)

        val seek = view.findViewById<SeekBar>(R.id.seekQty)
        val tvQty = view.findViewById<TextView>(R.id.tvQty)

        val btnSellQty = view.findViewById<MaterialButton>(R.id.btnSellQty)
        val btnSellAll = view.findViewById<MaterialButton>(R.id.btnSellAll)
        val btnSendQty = view.findViewById<MaterialButton>(R.id.btnSendQty)
        val btnSendAll = view.findViewById<MaterialButton>(R.id.btnSendAll)

        tvTitle.text = "${product.emoji} ${product.title} • Stok: $stock"
        tvSinglePrice.text = "Tekli: ${unitPrice(product)}₺"
        tvBulkPrice.text = "Çoklu(100+): ${bulkUnitPrice(product)}₺"

        seek.max = max(0, stock - 1)
        seek.progress = 0

        var qty = 1
        tvQty.text = "Adet: $qty"

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                qty = progress + 1
                tvQty.text = "Adet: $qty"
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        val dlg = AlertDialog.Builder(this)
            .setView(view)
            .setNegativeButton("Kapat", null)
            .create()

        // SAT
        btnSellQty.setOnClickListener {
            val ok = depotStore.remove(MapType.Ciftlik, product, qty)
            if (!ok) {
                toast("Yetersiz stok!")
                return@setOnClickListener
            }

            val pricePer = if (qty >= 100) bulkUnitPrice(product) else unitPrice(product)
            val earn = pricePer * qty

            addMoney(earn)
            saveAndRefresh()
            dlg.dismiss()
            toast("✅ Satıldı: +${earn}₺")
        }

        // TÜMÜNÜ SAT
        btnSellAll.setOnClickListener {
            val cur = depotStore.getInventory(MapType.Ciftlik)[product] ?: 0
            if (cur <= 0) return@setOnClickListener

            val ok = depotStore.remove(MapType.Ciftlik, product, cur)
            if (!ok) {
                toast("Yetersiz stok!")
                return@setOnClickListener
            }

            val pricePer = if (cur >= 100) bulkUnitPrice(product) else unitPrice(product)
            val earn = pricePer * cur

            addMoney(earn)
            saveAndRefresh()
            dlg.dismiss()
            toast("✅ Tümü satıldı: +${earn}₺")
        }

        // GÖNDER
        btnSendQty.setOnClickListener {
            pickSendTarget { target ->
                val ok = depotStore.remove(MapType.Ciftlik, product, qty)
                if (!ok) {
                    toast("Yetersiz stok!")
                    return@pickSendTarget
                }
                depotStore.add(target, product, qty)
                saveAndRefresh()
                dlg.dismiss()
                toast("📦 Gönderildi: $qty adet → ${target.name}")
            }
        }

        // TÜMÜNÜ GÖNDER
        btnSendAll.setOnClickListener {
            pickSendTarget { target ->
                val cur = depotStore.getInventory(MapType.Ciftlik)[product] ?: 0
                if (cur <= 0) return@pickSendTarget

                val ok = depotStore.remove(MapType.Ciftlik, product, cur)
                if (!ok) {
                    toast("Yetersiz stok!")
                    return@pickSendTarget
                }
                depotStore.add(target, product, cur)
                saveAndRefresh()
                dlg.dismiss()
                toast("📦 Tümü gönderildi: $cur adet → ${target.name}")
            }
        }

        dlg.show()
    }

    private fun pickSendTarget(onPicked: (MapType) -> Unit) {
        val targets = listOf(
            MapType.Sehir,
            MapType.OSB,
            MapType.KucukOSB,
            MapType.Hayvancilik,
            MapType.Madencilik
        )
        val names = targets.map { it.name }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Nereye gönderilsin?")
            .setItems(names) { _, idx -> onPicked(targets[idx]) }
            .setNegativeButton("İptal", null)
            .show()
    }

    // ----------------------------
    // SLOT ACTIONS
    // ----------------------------
    private fun confirmUnlock(slot: TarlaSlot) {
        AlertDialog.Builder(this)
            .setTitle("🔓 Tarla Aç")
            .setMessage("${slot.unlockPrice} TL ödeyip açmak istiyor musun?")
            .setPositiveButton("Aç") { _, _ ->
                if (!moneyStore.trySpend(slot.unlockPrice)) {
                    toast("Yetersiz para!")
                    return@setPositiveButton
                }
                slot.isUnlocked = true
                slot.acresOwned = 5
                saveAndRefresh()
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    private fun onAction(slot: TarlaSlot) {
        if (!slot.isUnlocked) return

        val isEmpty = slot.product == null
        val isReady = (!isEmpty && slot.phase == SlotPhase.READY)

        when {
            isEmpty -> showProductSelect(slot)
            isReady -> doHarvest(slot)
            else -> Unit
        }
    }

    private fun showProductSelect(slot: TarlaSlot) {
        val products = Product.values().filter { it.canPlant }.toTypedArray()


        val items = products.map { p ->
            val acres = max(5, slot.acresOwned)
            val yield = p.yieldPerAcre * acres
            val cost = p.seedCostPerAcre * acres
            "${p.emoji} ${p.title} | Verim: $yield | Maliyet: $cost"
        }.toTypedArray()

       AlertDialog.Builder(this)
            .setTitle("Ürünler | Verim | Maliyet")
            .setItems(items) { _, index ->
                val p = products[index]
                val acres = max(5, slot.acresOwned)
                val cost = p.seedCostPerAcre * acres
                if (!moneyStore.trySpend(cost)) {
                    toast("Yetersiz para!")
                    return@setItems
                }
                startPlant(slot, p)
            }
            .setNegativeButton("Kapat", null)
            .show()


    }

    private fun startPlant(slot: TarlaSlot, p: Product) {
        slot.product = p
        slot.phase = SlotPhase.PLANTED
        slot.phaseStartedAt = System.currentTimeMillis()
        saveAndRefresh()
    }

    private fun doHarvest(slot: TarlaSlot) {
        val p = slot.product ?: return
        val acres = max(5, slot.acresOwned)

        val sizeFactor = 5f / acres.toFloat()
        val boostFactor =
            1f + (slot.workerCount * 0.05f * sizeFactor) +
                    (slot.irrigationLevel * 0.08f * sizeFactor) +
                    (slot.fertilizerLevel * 0.10f * sizeFactor)

        val base = p.yieldPerAcre * acres
        val totalYield = (base * boostFactor).toInt().coerceAtLeast(0)

        depotStore.add(MapType.Ciftlik, p, totalYield)

        slot.lastHarvestedAt = System.currentTimeMillis()
        slot.product = null
        slot.phase = SlotPhase.IDLE
        slot.phaseStartedAt = 0L

        saveAndRefresh()
        toast("✅ $totalYield adet hasat edildi")
    }

    private fun onBoostPurchased(slot: TarlaSlot, type: TarlaSlotAdapter.BoostType) {
        val price = boostPrice(slot, type)
        if (!moneyStore.trySpend(price)) {
            toast("Yetersiz para!")
            return
        }
        when (type) {
            TarlaSlotAdapter.BoostType.WORKER -> slot.workerCount += 1
            TarlaSlotAdapter.BoostType.WATER -> slot.irrigationLevel += 1
            TarlaSlotAdapter.BoostType.FERTILIZER -> slot.fertilizerLevel += 1
        }
        saveAndRefresh()
    }

    private fun onGrowPurchased(slot: TarlaSlot) {
        val price = growPrice(slot)
        if (!moneyStore.trySpend(price)) {
            toast("Yetersiz para!")
            return
        }
        slot.acresOwned += 5
        saveAndRefresh()
    }

    // ----------------------------
    // PRICES
    // ----------------------------
    private fun boostPrice(slot: TarlaSlot, type: TarlaSlotAdapter.BoostType): Int {
        val acres = max(5, slot.acresOwned)
        return when (type) {
            TarlaSlotAdapter.BoostType.WORKER -> 150 + acres * 10
            TarlaSlotAdapter.BoostType.WATER -> 120 + acres * 8
            TarlaSlotAdapter.BoostType.FERTILIZER -> 200 + acres * 12
        }
    }

    private fun growPrice(slot: TarlaSlot): Int {
        val acres = max(5, slot.acresOwned)
        return 1000 + acres * 50
    }

    private fun unitPrice(p: Product): Int = marketPrices[p] ?: p.baseSellPrice

    private fun addMoney(amount: Int) {
        val cur = moneyStore.getMoney()
        moneyStore.setMoney(cur + max(0, amount))
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    companion object {
        private const val MARKET_PERIOD_MS = 60_000L
    }


private fun showFarmDepotDialog() {
    val inv = depotStore.getInventory(MapType.Ciftlik)
    val items = inv.entries.filter { it.value > 0 }.map { it.key }
    if (items.isEmpty()) {
        Toast.makeText(this, "Çiftlik deposu boş", Toast.LENGTH_SHORT).show()
        return
    }
    val arr = items.map { p -> "${p.emoji} ${p.title} • ${inv[p] ?: 0}" }.toTypedArray()
    AlertDialog.Builder(this)
        .setTitle("Çiftlik Deposu")
        .setItems(arr, null)
        .setPositiveButton("Kapat", null)
        .show()
}
}
