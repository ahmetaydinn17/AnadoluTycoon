package com.example.anadolutycoon

import android.content.Context

/**
 * Fabrikaların çalışma durumunu (isWorking, startedAt, totalSeconds, plannedCount)
 * SharedPreferences ile saklar. Böylece uygulama kapanıp açılsa bile üretim
 * kaldığı yerden devam eder ve bitmişse açılışta tamamlanır.
 */
class FactoryStateStore(context: Context) {

    private val prefs = context.getSharedPreferences("factory_state_v1", Context.MODE_PRIVATE)

    data class State(
        val isWorking: Boolean,
        val startedAt: Long,
        val totalSeconds: Int,
        val plannedCount: Int
    )

    private fun keyPrefix(mapType: MapType, factoryId: String): String = "${mapType.name}__${factoryId}"

    fun load(mapType: MapType, factoryId: String): State? {
        val p = keyPrefix(mapType, factoryId)
        val has = prefs.contains("${p}_isWorking")
        if (!has) return null

        return State(
            isWorking = prefs.getBoolean("${p}_isWorking", false),
            startedAt = prefs.getLong("${p}_startedAt", 0L),
            totalSeconds = prefs.getInt("${p}_totalSeconds", 0),
            plannedCount = prefs.getInt("${p}_plannedCount", 0)
        )
    }

    fun save(mapType: MapType, factoryId: String, state: State) {
        val p = keyPrefix(mapType, factoryId)
        prefs.edit()
            .putBoolean("${p}_isWorking", state.isWorking)
            .putLong("${p}_startedAt", state.startedAt)
            .putInt("${p}_totalSeconds", state.totalSeconds)
            .putInt("${p}_plannedCount", state.plannedCount)
            .apply()
    }

    fun clear(mapType: MapType, factoryId: String) {
        val p = keyPrefix(mapType, factoryId)
        prefs.edit()
            .remove("${p}_isWorking")
            .remove("${p}_startedAt")
            .remove("${p}_totalSeconds")
            .remove("${p}_plannedCount")
            .apply()
    }
}
