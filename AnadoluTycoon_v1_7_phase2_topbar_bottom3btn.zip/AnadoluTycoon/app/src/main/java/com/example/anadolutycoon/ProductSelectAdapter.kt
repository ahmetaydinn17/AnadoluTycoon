package com.example.anadolutycoon

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView

class ProductSelectAdapter(
    private val context: Context,
    private val items: List<Product>
) : BaseAdapter() {

    override fun getCount() = items.size
    override fun getItem(position: Int) = items[position]
    override fun getItemId(position: Int) = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val v = convertView ?: LayoutInflater.from(context).inflate(R.layout.item_product_select_row, parent, false)
        val p = getItem(position)

        v.findViewById<TextView>(R.id.tvProduct).text = "${p.emoji} ${p.title}"
        v.findViewById<TextView>(R.id.tvYield).text = "${p.yieldPerAcre}"
        v.findViewById<TextView>(R.id.tvCost).text = "${p.seedCostPerAcre}"
        v.findViewById<TextView>(R.id.tvOther).text =
            "Ekim: ${p.plantSeconds}s • Büyüme: ${p.growSeconds}s • Hasat: ${p.harvestSeconds}s"

        return v
    }
}
