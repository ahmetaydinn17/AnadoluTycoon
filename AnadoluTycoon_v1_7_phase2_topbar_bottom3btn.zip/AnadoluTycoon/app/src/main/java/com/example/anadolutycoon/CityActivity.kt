package com.example.anadolutycoon

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.ListView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import kotlin.math.max

class CityActivity : AppCompatActivity() {

    private lateinit var depotStore: DepotStore
    private lateinit var moneyStore: GlobalMoneyStore
    private lateinit var marketStore: MarketStore
    private lateinit var cityStore: CityStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_city)

        depotStore = DepotStore(this)
        moneyStore = GlobalMoneyStore(this)
        marketStore = MarketStore(this)
        cityStore = CityStore(this)

        val tvTop = findViewById<TextView>(R.id.tvMoney)
        val btnMainMenu = findViewById<MaterialButton>(R.id.btnMainMenu)
        val btnMapDepot = findViewById<MaterialButton>(R.id.btnMapDepot)
        btnMapDepot.text = "Şehir Depo"
        val btnGlobalDepot = findViewById<MaterialButton>(R.id.btnGlobalDepot)
        val btnMarket = findViewById<MaterialButton>(R.id.btnMarket)

        val cardManav = findViewById<MaterialCardView>(R.id.cardManav)
        val cardToptanci = findViewById<MaterialCardView>(R.id.cardToptanci)
        val cardIhracat = findViewById<MaterialCardView>(R.id.cardIhracat)

        fun refreshTop() {
    val money = moneyStore.getMoney()
    val stock = depotStore.getInventory(MapType.Sehir).values.sum()
    tvTop.text = UiBars.topBarText(money, stock, "Şehir")
}
        btnMapDepot.setOnClickListener { showDepotDialog() }
        btnMarket.setOnClickListener { showMarketDialog() }

        cardManav.setOnClickListener { showShopDialog(CityStore.Shop.MANAV) }
        cardToptanci.setOnClickListener { showShopDialog(CityStore.Shop.TOPTANCI) }
        cardIhracat.setOnClickListener { showShopDialog(CityStore.Shop.IHRACAT) }

        refreshTop()
        refreshShopCards()
    }

    override fun onResume() {
        super.onResume()
        refreshHeader()
    }

    private fun refreshHeader() {
        val tvTop = findViewById<TextView>(R.id.tvMoney)
        val money = moneyStore.getMoney()
        val stock = depotStore.getInventory(MapType.Sehir).values.sum()
        tvTop.text = UiBars.topBarText(money, stock, "Şehir")
        refreshShopCards()
    }

    private fun refreshShopCards() {
        fun setCard(cardId: Int, titleId: Int, descId: Int, shop: CityStore.Shop) {
            val card = findViewById<MaterialCardView>(cardId)
            val tvTitle = card.findViewById<TextView>(titleId)
            val tvDesc = card.findViewById<TextView>(descId)
            val lv = cityStore.getLevel(shop)
            val mul = cityStore.getMultiplier(shop)
            tvTitle.text = "${cityStore.shopTitle(shop)} • Lv.$lv"
            tvDesc.text = "Satış çarpanı: x${String.format("%.2f", mul)} • Yükseltme: ${formatMoney(cityStore.upgradeCost(shop))}₺"
        }

        setCard(R.id.cardManav, R.id.tvManavTitle, R.id.tvManavDesc, CityStore.Shop.MANAV)
        setCard(R.id.cardToptanci, R.id.tvToptanciTitle, R.id.tvToptanciDesc, CityStore.Shop.TOPTANCI)
        setCard(R.id.cardIhracat, R.id.tvIhracatTitle, R.id.tvIhracatDesc, CityStore.Shop.IHRACAT)
    }

    private fun showShopDialog(shop: CityStore.Shop) {
        val level = cityStore.getLevel(shop)
        val mul = cityStore.getMultiplier(shop)
        val cost = cityStore.upgradeCost(shop)

        AlertDialog.Builder(this)
            .setTitle(cityStore.shopTitle(shop))
            .setMessage(
                "Seviye: $level\n" +
                    "Satış çarpanı: x${String.format("%.2f", mul)}\n\n" +
                    "Yükseltme maliyeti: ${formatMoney(cost)}₺\n\n" +
                    "Not: Satışlar Şehir Deposu üzerinden yapılır."
            )
            .setPositiveButton("Yükselt") { _, _ ->
                val money = moneyStore.getMoney()
                if (money < cost) {
                    toast("Yetersiz para")
                    return@setPositiveButton
                }
                moneyStore.setMoney(money - cost)
                cityStore.upgrade(shop)
                refreshHeader()
                toast("✅ Yükseltildi: Lv.${level + 1}")
            }
            .setNegativeButton("Kapat", null)
            .show()
    }

    private fun showMarketDialog() {
        marketStore.ensureUpToDate()

        val v = layoutInflater.inflate(R.layout.dialog_market, null)
        val lv = v.findViewById<ListView>(R.id.lvMarket)
        val btnClose = v.findViewById<TextView>(R.id.btnClose)

        val rows: List<MarketRow> = Product.values().map { p ->
            MarketRow(p, marketStore.unitPrice(p), marketStore.bulkUnitPrice(p))
        }
        lv.adapter = MarketListAdapter(this, rows)

        val dlg = AlertDialog.Builder(this)
            .setTitle("Piyasalar (Güncellenme: ${marketStore.getRemainingSec()}s)")
            .setView(v)
            .create()

        btnClose.setOnClickListener { dlg.dismiss() }
        dlg.show()
    }

    private fun showDepotDialog() {
        val inv = depotStore.getInventory(MapType.Sehir)
        val products = inv.entries.filter { it.value > 0 }.map { it.key }

        if (products.isEmpty()) {
            toast("Şehir deposu boş")
            return
        }

        val arr = products.map { p -> "${p.emoji} ${p.title} • ${inv[p] ?: 0}" }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Şehir Deposu")
            .setItems(arr) { _, idx ->
                val p = products[idx]
                val stock = inv[p] ?: 0
                showTradeDialog(p, stock)
            }
            .setNegativeButton("Kapat", null)
            .show()
    }

    private fun showTradeDialog(product: Product, stock: Int) {
        if (stock <= 0) return

        val view = layoutInflater.inflate(R.layout.dialog_trade_product, null)

        val tvTitle = view.findViewById<TextView>(R.id.tvTradeTitle)
        val tvSinglePrice = view.findViewById<TextView>(R.id.tvSinglePrice)
        val tvBulkPrice = view.findViewById<TextView>(R.id.tvBulkPrice)

        val seek = view.findViewById<SeekBar>(R.id.seekQty)
        val tvQty = view.findViewById<TextView>(R.id.tvQty)

        val btnSellQty = view.findViewById<MaterialButton>(R.id.btnSellQty)
        val btnSellAll = view.findViewById<MaterialButton>(R.id.btnSellAll)
        val btnSendQty = view.findViewById<MaterialButton>(R.id.btnSendQty)
        val btnSendAll = view.findViewById<MaterialButton>(R.id.btnSendAll)

        val mul = cityStore.bestMultiplier()
        val u = (marketStore.unitPrice(product) * mul).toInt().coerceAtLeast(1)
        val b = (marketStore.bulkUnitPrice(product) * mul).toInt().coerceAtLeast(1)

        tvTitle.text = "${product.emoji} ${product.title} • Stok: $stock"
        tvSinglePrice.text = "Tekli: ${formatMoney(u)}₺ (Şehir)"
        tvBulkPrice.text = "Çoklu(100+): ${formatMoney(b)}₺ (Şehir)"

        seek.max = max(0, stock - 1)
        seek.progress = 0

        var qty = 1
        tvQty.text = "Adet: $qty"

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                qty = progress + 1
                tvQty.text = "Adet: $qty"
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        val dlg = AlertDialog.Builder(this)
            .setView(view)
            .setNegativeButton("Kapat", null)
            .create()

        fun sell(amount: Int) {
            val ok = depotStore.remove(MapType.Sehir, product, amount)
            if (!ok) {
                toast("Yetersiz stok!")
                return
            }
            val pricePer = if (amount >= 100) b else u
            val earn = pricePer * amount
            moneyStore.setMoney(moneyStore.getMoney() + earn)
            refreshHeader()
            dlg.dismiss()
            toast("✅ Satıldı: +${formatMoney(earn)}₺")
        }

        btnSellQty.setOnClickListener { sell(qty) }
        btnSellAll.setOnClickListener {
            val cur = depotStore.getInventory(MapType.Sehir)[product] ?: 0
            if (cur > 0) sell(cur)
        }

        btnSendQty.setOnClickListener {
            pickSendTarget { target ->
                val ok = depotStore.remove(MapType.Sehir, product, qty)
                if (!ok) {
                    toast("Yetersiz stok!")
                    return@pickSendTarget
                }
                depotStore.add(target, product, qty)
                refreshHeader()
                dlg.dismiss()
                toast("📦 Gönderildi: $qty adet → ${target.name}")
            }
        }

        btnSendAll.setOnClickListener {
            pickSendTarget { target ->
                val cur = depotStore.getInventory(MapType.Sehir)[product] ?: 0
                if (cur <= 0) return@pickSendTarget
                val ok = depotStore.remove(MapType.Sehir, product, cur)
                if (!ok) {
                    toast("Yetersiz stok!")
                    return@pickSendTarget
                }
                depotStore.add(target, product, cur)
                refreshHeader()
                dlg.dismiss()
                toast("📦 Tümü gönderildi: $cur adet → ${target.name}")
            }
        }

        dlg.show()
    }

    private fun pickSendTarget(onPicked: (MapType) -> Unit) {
        val targets = listOf(
            MapType.Koy,
            MapType.OSB,
            MapType.KucukOSB,
            MapType.Hayvancilik,
            MapType.Madencilik
        )
        val names = targets.map { it.name }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Nereye gönderilsin?")
            .setItems(names) { _, idx -> onPicked(targets[idx]) }
            .setNegativeButton("İptal", null)
            .show()
    }

    private fun formatMoney(v: Int): String {
        val s = v.toString()
        val sb = StringBuilder()
        for (i in s.indices) {
            sb.append(s[i])
            val left = s.length - i - 1
            if (left > 0 && left % 3 == 0) sb.append('.')
        }
        return sb.toString()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
