package com.example.anadolutycoon

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton

class OsbActivity : AppCompatActivity() {

    private lateinit var depotStore: DepotStore
    private lateinit var moneyStore: GlobalMoneyStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_osb)

        depotStore = DepotStore(this)
        moneyStore = GlobalMoneyStore(this)

        val tvTop = findViewById<TextView>(R.id.tvMoney)
        val rv = findViewById<RecyclerView>(R.id.rvFactories)

        val btnMainMenu = findViewById<MaterialButton>(R.id.btnMainMenu)
        val btnGlobalDepot = findViewById<MaterialButton>(R.id.btnGlobalDepot)
        val btnMapDepot = findViewById<MaterialButton>(R.id.btnMapDepot)

        fun refreshTop() {
    val money = moneyStore.getMoney()
    val stock = depotStore.getInventory(MapType.OSB).values.sum()
    tvTop.text = UiBars.topBarText(money, stock, "OSB")
}

        btnMainMenu.setOnClickListener { finish() }
        btnGlobalDepot.setOnClickListener { startActivity(Intent(this, GlobalDepotActivity::class.java)) }

        
        btnMapDepot.text = "OSB Depo"
        btnMapDepot.setOnClickListener { showDepotDialog() }
val factories = listOf(
            Factory("steel", "⚙️", "Çelik Fabrikası", Product.DEMIR_CEVHER, 3, Product.CELIK, 1, 16),
            Factory("bread", "🍞", "Fırın", Product.UN, 2, Product.EKMEK, 1, 10),
            Factory("cheese", "🧀", "Peynirhane", Product.SUT, 3, Product.PEYNIR, 1, 12),
            Factory("drypepper", "☀️🫑", "Biber Kurutma", Product.BIBER, 5, Product.KURUT_BIBER, 1, 14),
            Factory("feedplus", "🐄", "Yem (Gelişmiş)", Product.BUGDAY, 4, Product.YEM, 2, 14)
        )

        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = FactoryAdapter(
            context = this,
            factories = factories,
            depotStore = depotStore,
            moneyStore = moneyStore,
            mapType = MapType.OSB
        )

        refreshTop()
    }

    private fun formatMoney(v: Int): String {
        val s = v.toString()
        val sb = StringBuilder()
        for (i in s.indices) {
            sb.append(s[i])
            val left = s.length - i - 1
            if (left > 0 && left % 3 == 0) sb.append('.')
        }
        return sb.toString()
    }


private fun showDepotDialog() {
    val inv = depotStore.getInventory(MapType.OSB)
    val items = inv.entries.filter { it.value > 0 }.map { it.key }
    if (items.isEmpty()) {
        toast("OSB deposu boş")
        return
    }
    val arr = items.map { p -> "${p.emoji} ${p.title} • ${inv[p] ?: 0}" }.toTypedArray()
    android.app.AlertDialog.Builder(this)
        .setTitle("OSB Deposu")
        .setItems(arr, null)
        .setPositiveButton("Kapat", null)
        .show()
}
}
