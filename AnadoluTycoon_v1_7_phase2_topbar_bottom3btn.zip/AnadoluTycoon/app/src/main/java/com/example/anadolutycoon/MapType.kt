package com.example.anadolutycoon

enum class MapType {
    Ciftlik,
    Koy,
    Sehir,
    OSB,
    KucukOSB,
    Madencilik,
    Hayvancilik
}
