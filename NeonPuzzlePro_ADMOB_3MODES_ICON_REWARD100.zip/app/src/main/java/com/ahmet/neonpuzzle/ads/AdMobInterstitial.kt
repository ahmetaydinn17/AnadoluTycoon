package com.ahmet.neonpuzzle.ads

import android.app.Activity
import android.content.Context
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Basit Interstitial yöneticisi.
 *
 * - Uygulama açılırken 1 kere load eder.
 * - Gösterince yeniden load eder.
 */
object AdMobInterstitial {

    // Debug = test ID, Release = gerçek ID
    private fun unitId(): String = AdIds.interstitialUnitId()

    private var interstitial: InterstitialAd? = null
    private val isLoading = AtomicBoolean(false)

    fun preload(context: Context) {
        if (interstitial != null) return
        if (!isLoading.compareAndSet(false, true)) return

        val request = AdRequest.Builder().build()
        InterstitialAd.load(
            context,
            unitId(),
            request,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitial = ad
                    isLoading.set(false)
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitial = null
                    isLoading.set(false)
                }
            }
        )
    }

    /**
     * Hazırsa gösterir. Göstermezse sessizce devam eder.
     */
    fun showIfReady(activity: Activity, onFinished: () -> Unit = {}) {
        val ad = interstitial
        if (ad == null) {
            preload(activity)
            onFinished()
            return
        }

        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                interstitial = null
                preload(activity)
                onFinished()
            }

            override fun onAdFailedToShowFullScreenContent(p0: com.google.android.gms.ads.AdError) {
                interstitial = null
                preload(activity)
                onFinished()
            }

            override fun onAdShowedFullScreenContent() {
                // Ad gösterildi.
            }
        }

        ad.show(activity)
    }
}
