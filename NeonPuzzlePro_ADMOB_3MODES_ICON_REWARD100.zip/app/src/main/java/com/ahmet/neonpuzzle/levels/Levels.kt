package com.ahmet.neonpuzzle.levels

/**
 * Basit level sistemi: asset'lerden sırayla level üretir.
 * İstersen ileride her level için özel resim/grit/kurallar ekleyebiliriz.
 */
object Levels {
    data class Level(
        val id: Int,
        val title: String,
        val grid: Int,
        val assetName: String,
    )

    // app/src/main/assets/images altındaki 30 görseli level görseli olarak kullanıyoruz.
    // (images/puzzle_1.jpg ... images/puzzle_30.jpg)
    private val assets: List<String> = (1..30).map { "images/puzzle_$it.jpg" }

    /** 30 level: 2x2'den 5x5'e kademeli artar. */
    val all: List<Level> = buildList {
        // 1-8  : 2x2
        for (i in 1..8) add(Level(i, "Level $i", 2, assets[i - 1]))
        // 9-16 : 3x3
        for (i in 9..16) add(Level(i, "Level $i", 3, assets[i - 1]))
        // 17-24: 4x4
        for (i in 17..24) add(Level(i, "Level $i", 4, assets[i - 1]))
        // 25-30: 5x5
        for (i in 25..30) add(Level(i, "Level $i", 5, assets[i - 1]))
    }

    fun byId(id: Int): Level? = all.firstOrNull { it.id == id }
}
