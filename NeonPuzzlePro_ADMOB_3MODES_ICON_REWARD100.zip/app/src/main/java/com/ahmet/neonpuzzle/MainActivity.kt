package com.ahmet.neonpuzzle

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.ahmet.neonpuzzle.levels.Levels
import com.ahmet.neonpuzzle.ui.NeonPuzzleTheme
import com.ahmet.neonpuzzle.ui.screens.GalleryScreen
import com.ahmet.neonpuzzle.ui.screens.HomeScreen
import com.ahmet.neonpuzzle.ui.screens.LevelScreen
import com.ahmet.neonpuzzle.ui.screens.LevelsScreen
import com.ahmet.neonpuzzle.ui.screens.PuzzleScreen
import com.ahmet.neonpuzzle.ui.screens.SettingsScreen
import com.ahmet.neonpuzzle.levels.GamePrefs
import com.ahmet.neonpuzzle.data.GamePrefs as Prefs
import com.ahmet.neonpuzzle.ui.i18n.LocalAppStrings
import com.ahmet.neonpuzzle.ui.i18n.S
import com.ahmet.neonpuzzle.ui.i18n.stringsFor

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val nav = rememberNavController()
            val ctx = LocalContext.current
            var langCode by remember { mutableStateOf(Prefs.language(ctx)) }

            CompositionLocalProvider(LocalAppStrings provides stringsFor(langCode)) {
                NeonPuzzleTheme {
                    val s = S()
                    val prefs = remember { GamePrefs(ctx) }
                    var showDaily by remember { mutableStateOf(false) }
                    var dailyAmount by remember { mutableStateOf(0) }

                LaunchedEffect(Unit) {
                    val now = System.currentTimeMillis()
                    val last = prefs.getLastDailyRewardMs()
                    val dayMs = 24L * 60L * 60L * 1000L
                    if (now - last >= dayMs) {
                        dailyAmount = 50
                        prefs.addCoins(dailyAmount)
                        prefs.setLastDailyRewardMs(now)
                        showDaily = true
                    }
                }

                    if (showDaily) {
                        AlertDialog(
                            onDismissRequest = { showDaily = false },
                            confirmButton = {
                                TextButton(onClick = { showDaily = false }) { Text(s.ok) }
                            },
                            title = { Text(s.dailyRewardTitle) },
                            text = { Text(s.dailyRewardText(dailyAmount)) }
                        )
                    }

                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        NavHost(navController = nav, startDestination = "home") {

                            composable("home") {
                                HomeScreen(
                                    onStart = { mode -> nav.navigate("levels/${mode.name}") },
                                    onGallery = { nav.navigate("level/${PuzzleMode.DRAG.name}") },
                                    onSettings = { nav.navigate("settings") }
                                )
                            }

                            composable("settings") {
                                SettingsScreen(
                                    onBack = { nav.popBackStack() },
                                    onLanguageChanged = { newCode ->
                                        Prefs.setLanguage(ctx, newCode)
                                        langCode = Prefs.language(ctx)
                                    }
                                )
                            }

                        // Mode seçildi -> Level listesi
                        composable(
                            route = "levels/{mode}",
                            arguments = listOf(navArgument("mode") { type = NavType.StringType })
                        ) { backStack ->
                            val modeName = backStack.arguments?.getString("mode") ?: PuzzleMode.DRAG.name
                            val mode = PuzzleMode.valueOf(modeName)

                            LevelsScreen(
                                mode = mode,
                                onBack = { nav.popBackStack() },
                                onPlayLevel = { levelId -> nav.navigate("playLevel/${mode.name}/$levelId") }
                            )
                        }

                        // Level oynatma (asset + grid otomatik)
                        composable(
                            route = "playLevel/{mode}/{levelId}",
                            arguments = listOf(
                                navArgument("mode") { type = NavType.StringType },
                                navArgument("levelId") { type = NavType.IntType }
                            )
                        ) { backStack ->
                            val mode = PuzzleMode.valueOf(backStack.arguments?.getString("mode") ?: PuzzleMode.DRAG.name)
                            val levelId = backStack.arguments?.getInt("levelId") ?: 1
                            val level = Levels.byId(levelId) ?: Levels.all.first()

                            PuzzleScreen(
                                mode = mode,
                                grid = level.grid,
                                imageRef = "asset:${level.assetName}",
                                levelId = level.id,
                                onBack = { nav.popBackStack() }
                            )
                        }

                        // Serbest oyun: eski ekranlar (zorluk/grid seçimi -> galeri)
                        composable(
                            route = "level/{mode}",
                            arguments = listOf(navArgument("mode") { type = NavType.StringType })
                        ) { backStack ->
                            val modeName = backStack.arguments?.getString("mode") ?: PuzzleMode.DRAG.name
                            val mode = PuzzleMode.valueOf(modeName)
                            LevelScreen(
                                mode = mode,
                                onBack = { nav.popBackStack() },
                                onNext = { grid -> nav.navigate("gallery?mode=${mode.name}&grid=$grid") }
                            )
                        }

                        composable(
                            route = "gallery?mode={mode}&grid={grid}",
                            arguments = listOf(
                                navArgument("mode") { type = NavType.StringType; defaultValue = PuzzleMode.DRAG.name },
                                navArgument("grid") { type = NavType.IntType; defaultValue = 2 }
                            )
                        ) { backStack ->
                            val mode = PuzzleMode.valueOf(backStack.arguments?.getString("mode") ?: PuzzleMode.DRAG.name)
                            val grid = backStack.arguments?.getInt("grid") ?: 2

                            GalleryScreen(
                                mode = mode,
                                grid = grid,
                                onBack = { nav.popBackStack() },
                                onStartWithAsset = { assetName ->
                                    nav.navigate("play/${mode.name}/$grid/${Uri.encode("asset:$assetName")}")
                                },
                                onStartWithUri = { uri ->
                                    nav.navigate("play/${mode.name}/$grid/${Uri.encode(uri.toString())}")
                                }
                            )
                        }

                        // Serbest oyun oynatma
                        composable(
                            route = "play/{mode}/{grid}/{image}",
                            arguments = listOf(
                                navArgument("mode") { type = NavType.StringType },
                                navArgument("grid") { type = NavType.IntType },
                                navArgument("image") { type = NavType.StringType }
                            )
                        ) { backStack ->
                            val mode = PuzzleMode.valueOf(backStack.arguments?.getString("mode") ?: PuzzleMode.DRAG.name)
                            val grid = backStack.arguments?.getInt("grid") ?: 2
                            val image = backStack.arguments?.getString("image") ?: ""

                            PuzzleScreen(
                                mode = mode,
                                grid = grid,
                                imageRef = Uri.decode(image),
                                levelId = null,
                                onBack = { nav.popBackStack() }
                            )
                        }
                        }
                    }
                }
            }
        }
    }
}
