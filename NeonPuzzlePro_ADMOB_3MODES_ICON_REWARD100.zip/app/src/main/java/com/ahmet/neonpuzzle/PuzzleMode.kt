package com.ahmet.neonpuzzle

enum class PuzzleMode {
    DRAG,   // Dokun-Değiştir
    SLIDE   // Klasik kaydırmalı (boş kare)
}
