package com.ahmet.neonpuzzle.puzzle

import com.ahmet.neonpuzzle.PuzzleMode
import kotlin.math.abs
import kotlin.random.Random

data class Tile(
    val id: Int,          // doğru sıradaki kimlik (0..n*n-1)
    val isBlank: Boolean, // slide modunda boş kare
)

data class PuzzleState(
    val mode: PuzzleMode,
    val grid: Int,
    val tiles: List<Tile>,
    val moves: Int = 0,
    val startMs: Long = System.currentTimeMillis()
)

object PuzzleEngine {

    fun newGame(mode: PuzzleMode, grid: Int, seed: Int? = null): PuzzleState {
        require(grid in 2..20)
        val n = grid * grid
        val base = List(n) { i ->
            val blank = (mode == PuzzleMode.SLIDE && i == n - 1)
            Tile(id = i, isBlank = blank)
        }
        val rng = seed?.let { Random(it) } ?: Random.Default

        val shuffled = when (mode) {
            PuzzleMode.DRAG -> base.shuffled(rng)
            PuzzleMode.SLIDE -> shuffledSolvable(base, grid, rng)
        }

        return PuzzleState(mode = mode, grid = grid, tiles = shuffled, moves = 0, startMs = System.currentTimeMillis())
    }

    /** Kayıttan devam için: tile id listesi -> PuzzleState */
    fun fromSaved(mode: PuzzleMode, grid: Int, tileIds: List<Int>, moves: Int, startMs: Long): PuzzleState {
        val n = grid * grid
        if (tileIds.size != n) return newGame(mode, grid)
        val tiles = tileIds.map { id ->
            val blank = (mode == PuzzleMode.SLIDE && id == n - 1)
            Tile(id = id, isBlank = blank)
        }
        return PuzzleState(mode = mode, grid = grid, tiles = tiles, moves = moves, startMs = startMs)
    }

    fun isSolved(state: PuzzleState): Boolean =
        state.tiles.withIndex().all { (idx, t) -> t.id == idx }

    /**
     * Basit ipucu: yanlış duran bir taşı, olması gereken konuma yaklaştırır.
     * DRAG modunda: yanlış yerdeki taşı doğru yere koymak için gerekli swap'ı yapar.
     * SLIDE modunda: boş kare ile komşu olan ve doğru pozisyona yaklaşan bir hamle dener.
     */
    fun applyHint(state: PuzzleState): PuzzleState {
        if (isSolved(state)) return state

        return when (state.mode) {
            PuzzleMode.DRAG -> {
                val i = state.tiles.withIndex().indexOfFirst { (idx, t) -> t.id != idx }
                if (i < 0) state else {
                    val wantId = i
                    val j = state.tiles.indexOfFirst { it.id == wantId }
                    if (j < 0) state else swap(state, i, j)
                }
            }
            PuzzleMode.SLIDE -> {
                val blankIndex = state.tiles.indexOfFirst { it.isBlank }
                if (blankIndex < 0) return state
                // Try all adjacent tiles; pick the one that increases number of correct tiles
                val neighbors = listOf(
                    blankIndex - 1, blankIndex + 1,
                    blankIndex - state.grid, blankIndex + state.grid
                ).filter { it in state.tiles.indices && isAdjacent(it, blankIndex, state.grid) }

                val currentCorrect = state.tiles.withIndex().count { (idx, t) -> t.id == idx }
                var best: PuzzleState = state
                var bestCorrect = currentCorrect
                for (n in neighbors) {
                    val candidate = trySlideMove(state, n)
                    val candCorrect = candidate.tiles.withIndex().count { (idx, t) -> t.id == idx }
                    if (candCorrect > bestCorrect) {
                        bestCorrect = candCorrect
                        best = candidate
                    }
                }
                // If none improves, just do a legal move (first neighbor)
                if (best != state) best else neighbors.firstOrNull()?.let { trySlideMove(state, it) } ?: state
            }
        }
    }

    fun trySlideMove(state: PuzzleState, index: Int): PuzzleState {
        if (state.mode != PuzzleMode.SLIDE) return state
        val grid = state.grid
        val blankIndex = state.tiles.indexOfFirst { it.isBlank }
        if (blankIndex < 0) return state
        if (!isAdjacent(index, blankIndex, grid)) return state

        val mutable = state.tiles.toMutableList()
        mutable[blankIndex] = mutable[index]
        mutable[index] = Tile(id = state.tiles[blankIndex].id, isBlank = true) // keep blank
        return state.copy(tiles = mutable, moves = state.moves + 1)
    }

    fun swap(state: PuzzleState, a: Int, b: Int): PuzzleState {
        if (a == b) return state
        // Slide modunda blank'ı da swaplamaya izin veriyoruz (dokun-değiştir değil ama reset için faydalı),
        // UI tarafında slide modunda swap çağırmayacağız.
        val mutable = state.tiles.toMutableList()
        val ta = mutable[a]
        val tb = mutable[b]
        mutable[a] = tb
        mutable[b] = ta
        return state.copy(tiles = mutable, moves = state.moves + 1)
    }

    private fun isAdjacent(i: Int, j: Int, grid: Int): Boolean {
        val r1 = i / grid; val c1 = i % grid
        val r2 = j / grid; val c2 = j % grid
        return (abs(r1 - r2) + abs(c1 - c2)) == 1
    }

    // --- Solvable shuffle for N-puzzle ---
    private fun shuffledSolvable(base: List<Tile>, grid: Int, rng: Random): List<Tile> {
        val n = base.size
        val baseIds = base.map { it.id }
        val blankId = n - 1

        var attempt = 0
        while (true) {
            attempt++
            val ids = baseIds.shuffled(rng).toMutableList()

            // Ensure exactly one blank (blankId) present (it is)
            // Keep blank as id==blankId
            if (ids == baseIds) continue

            if (isSolvable(ids, grid, blankId)) {
                return ids.map { id -> Tile(id = id, isBlank = (id == blankId)) }
            }
            if (attempt > 5000) {
                // fallback: deterministic solvable by swapping two non-blank tiles
                val ids2 = baseIds.toMutableList()
                ids2[0] = 1; ids2[1] = 0
                return ids2.map { id -> Tile(id = id, isBlank = (id == blankId)) }
            }
        }
    }

    private fun isSolvable(ids: List<Int>, grid: Int, blankId: Int): Boolean {
        val inversions = countInversions(ids.filter { it != blankId })
        val blankIndex = ids.indexOf(blankId)
        val blankRowFromBottom = grid - (blankIndex / grid) // 1..grid

        return if (grid % 2 == 1) {
            inversions % 2 == 0
        } else {
            // even grid:
            // solvable if blank on even row from bottom and inversions odd
            // or blank on odd row from bottom and inversions even
            val blankEven = (blankRowFromBottom % 2 == 0)
            val invEven = (inversions % 2 == 0)
            (blankEven && !invEven) || (!blankEven && invEven)
        }
    }

    private fun countInversions(arr: List<Int>): Int {
        var inv = 0
        for (i in arr.indices) {
            for (j in i + 1 until arr.size) {
                if (arr[i] > arr[j]) inv++
            }
        }
        return inv
    }
}
