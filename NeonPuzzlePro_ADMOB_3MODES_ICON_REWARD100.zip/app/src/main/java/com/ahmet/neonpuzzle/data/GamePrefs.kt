package com.ahmet.neonpuzzle.data

import android.content.Context
import android.content.SharedPreferences
import java.security.MessageDigest

object GamePrefs {
    private const val PREF = "neon_puzzle_prefs"

    // Language ("tr" / "en")
    private const val KEY_LANG = "lang_code"

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun language(context: Context): String =
        prefs(context).getString(KEY_LANG, "tr") ?: "tr"

    fun setLanguage(context: Context, code: String) {
        val normalized = if (code.lowercase().startsWith("en")) "en" else "tr"
        prefs(context).edit().putString(KEY_LANG, normalized).apply()
    }

    data class SavedRun(
        val tiles: List<Int>,
        val moves: Int,
        val startedAtMs: Long,
    )

    fun getUnlockedLevel(context: Context, modeName: String): Int =
        prefs(context).getInt("unlocked_$modeName", 1).coerceAtLeast(1)

    fun setUnlockedLevel(context: Context, modeName: String, levelId: Int) {
        prefs(context).edit().putInt("unlocked_$modeName", levelId).apply()
    }

    fun markLevelCompleted(context: Context, modeName: String, levelId: Int) {
        val key = "completed_$modeName"
        val set = prefs(context).getStringSet(key, emptySet())?.toMutableSet() ?: mutableSetOf()
        set.add(levelId.toString())
        prefs(context).edit().putStringSet(key, set).apply()

        val unlocked = getUnlockedLevel(context, modeName)
        if (levelId >= unlocked) {
            setUnlockedLevel(context, modeName, levelId + 1)
        }
    }

    fun isLevelCompleted(context: Context, modeName: String, levelId: Int): Boolean {
        val set = prefs(context).getStringSet("completed_$modeName", emptySet()) ?: emptySet()
        return set.contains(levelId.toString())
    }

    /**
     * Aynı puzzle (mode+grid+imageRef) için kayıt anahtarı.
     * Key'ler kısa olsun diye md5 hash kullanıyoruz.
     */
    fun runKey(modeName: String, grid: Int, imageRef: String): String {
        val raw = "${modeName}|${grid}|${imageRef}"
        val md5 = MessageDigest.getInstance("MD5").digest(raw.toByteArray())
        val hex = md5.joinToString("") { "%02x".format(it) }
        return "run_$hex"
    }

    fun saveRun(context: Context, key: String, tiles: List<Int>, moves: Int, startedAtMs: Long) {
        prefs(context).edit()
            .putString("${key}_tiles", tiles.joinToString(","))
            .putInt("${key}_moves", moves)
            .putLong("${key}_start", startedAtMs)
            .apply()
    }

    fun loadRun(context: Context, key: String): SavedRun? {
        val p = prefs(context)
        val tilesStr = p.getString("${key}_tiles", null) ?: return null
        val tiles = tilesStr.split(',').mapNotNull { it.toIntOrNull() }
        if (tiles.isEmpty()) return null
        val moves = p.getInt("${key}_moves", 0)
        val start = p.getLong("${key}_start", 0L)
        return SavedRun(tiles, moves, start)
    }

    fun clearRun(context: Context, key: String) {
        prefs(context).edit()
            .remove("${key}_tiles")
            .remove("${key}_moves")
            .remove("${key}_start")
            .apply()
    }

    // ----------------------------
    // Coin + settings helpers
    // ----------------------------
    fun coins(context: Context): Int = prefs(context).getInt(KEY_COINS, 0).coerceAtLeast(0)

    fun setCoins(context: Context, value: Int) {
        prefs(context).edit().putInt(KEY_COINS, value.coerceAtLeast(0)).apply()
    }

    fun addCoins(context: Context, delta: Int) {
        setCoins(context, coins(context) + delta)
    }

    fun lastDailyRewardMs(context: Context): Long = prefs(context).getLong(KEY_LAST_DAILY, 0L)

    fun setLastDailyRewardMs(context: Context, ms: Long) {
        prefs(context).edit().putLong(KEY_LAST_DAILY, ms).apply()
    }

    fun isSoundOn(context: Context): Boolean = prefs(context).getBoolean(KEY_SOUND, true)
    fun setSoundOn(context: Context, on: Boolean) {
        prefs(context).edit().putBoolean(KEY_SOUND, on).apply()
    }

    fun isVibrateOn(context: Context): Boolean = prefs(context).getBoolean(KEY_VIBRATE, true)
    fun setVibrateOn(context: Context, on: Boolean) {
        prefs(context).edit().putBoolean(KEY_VIBRATE, on).apply()
    }

    fun hintCost(context: Context): Int = prefs(context).getInt(KEY_HINT_COST, DEFAULT_HINT_COST)
}

private const val KEY_COINS = "coins"
private const val KEY_HINT_COST = "hint_cost"
private const val DEFAULT_HINT_COST = 25
private const val KEY_LAST_DAILY = "last_daily_reward"
private const val KEY_SOUND = "sound_on"
private const val KEY_VIBRATE = "vibrate_on"


