package com.ahmet.neonpuzzle.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.ahmet.neonpuzzle.levels.GamePrefs
import com.ahmet.neonpuzzle.data.GamePrefs as Prefs
import com.ahmet.neonpuzzle.ui.i18n.S

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onLanguageChanged: (String) -> Unit
) {
    val ctx = LocalContext.current
    val s = S()
    val prefs = remember { GamePrefs(ctx) }

    var soundOn by remember { mutableStateOf(prefs.isSoundOn()) }
    var vibrateOn by remember { mutableStateOf(prefs.isVibrateOn()) }

    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text(s.settings) },
                navigationIcon = {
                    TextButton(onClick = onBack) { Text(s.back) }
                }
            )
        }
    ) { pad ->
        Column(
            modifier = Modifier
                .padding(pad)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(s.sound)
                        Switch(
                            checked = soundOn,
                            onCheckedChange = {
                                soundOn = it
                                prefs.setSoundOn(it)
                            }
                        )
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(s.vibration)
                        Switch(
                            checked = vibrateOn,
                            onCheckedChange = {
                                vibrateOn = it
                                prefs.setVibrateOn(it)
                            }
                        )
                    }
                }
            }

            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(s.language, style = MaterialTheme.typography.titleMedium)

                    var expanded by remember { mutableStateOf(false) }
                    var current by remember { mutableStateOf(Prefs.language(ctx)) }

                    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                        OutlinedTextField(
                            value = if (current == "en") s.english else s.turkish,
                            onValueChange = {},
                            readOnly = true,
                            modifier = Modifier.menuAnchor().fillMaxWidth(),
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) }
                        )
                        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            DropdownMenuItem(
                                text = { Text(s.turkish) },
                                onClick = {
                                    expanded = false
                                    current = "tr"
                                    Prefs.setLanguage(ctx, "tr")
                                    onLanguageChanged("tr")
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(s.english) },
                                onClick = {
                                    expanded = false
                                    current = "en"
                                    Prefs.setLanguage(ctx, "en")
                                    onLanguageChanged("en")
                                }
                            )
                        }
                    }
                }
            }

            // (İstersen) burada kısa bir açıklama bırakabiliriz.
        }
    }
}
