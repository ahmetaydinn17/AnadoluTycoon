package com.ahmet.neonpuzzle.ui.i18n

import androidx.compose.runtime.Composable
import androidx.compose.runtime.ProvidableCompositionLocal
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf

/**
 * Runtime-switchable localization for Compose.
 * We keep it code-based to avoid dealing with dynamic Locale updates.
 */
data class AppStrings(
    val appName: String,
    val play: String,
    val freePlay: String,
    val levels: String,
    val settings: String,
    val back: String,
    val language: String,
    val turkish: String,
    val english: String,
    val sound: String,
    val vibration: String,
    val dailyReward: String,
    val dailyRewardTitle: String,
    val dailyRewardText: (Int) -> String,
    val ok: String,
    val claim: String,
    val claimed: String,
    val chooseMode: String,
    val modeDrag: String,
    val modeSlide: String,
    val modeLabel: String,
    val level: (Int) -> String,
    val openLevel: (Int) -> String,
    val difficultyGrid: (Int) -> String,
    val continueChoosePhoto: String,
    val choosePhoto: String,
    val pickFromPhone: String,
    val inGameImagesNote: String,
    val hint: (Int) -> String,
    val resetZoom: String,
    val moves: String,
    val time: String,
    val shuffle: String,
    val dragHelp: String,
    val slideHelp: String,
    val solvedTitle: String,
    val solvedLevelDone: String,
    val continueText: String,
    val retry: String,
    val menu: String,
    val selectedImage: (String) -> String,
    val watchAd: String,
)

fun stringsFor(langCode: String): AppStrings {
    val isEn = langCode.lowercase().startsWith("en")
    return if (isEn) {
        AppStrings(
            appName = "Neon Puzzle Pro",
            play = "Play",
            freePlay = "Free play",
            levels = "Levels",
            settings = "Settings",
            back = "Back",
            language = "Language",
            turkish = "Turkish",
            english = "English",
            sound = "Sound",
            vibration = "Vibration",
            dailyReward = "Daily reward",
            dailyRewardTitle = "Daily Reward",
            dailyRewardText = { amount -> "Daily login bonus: +$amount coins" },
            ok = "OK",
            claim = "Claim",
            claimed = "Claimed",
            chooseMode = "Choose mode",
            modeDrag = "Tap & Swap",
            modeSlide = "Classic Slide",
            modeLabel = "Mode",
            level = { id -> "Level $id" },
            openLevel = { id -> "Open level: $id" },
            difficultyGrid = { g -> "Difficulty (Grid): ${g}×${g}" },
            continueChoosePhoto = "Continue • Choose photo",
            choosePhoto = "Choose photo",
            pickFromPhone = "Pick from phone",
            inGameImagesNote = "In-game images (ready for 30 levels). If you want, you can put your own photos into assets/images and change this list.",
            hint = { cost -> "Hint ($cost)" },
            resetZoom = "Reset",
            moves = "Moves",
            time = "Time",
            shuffle = "Shuffle",
            dragHelp = "Tip: Tap a piece to select, then tap another to swap.",
            slideHelp = "Tip: Tap a tile next to the empty slot to slide.",
            solvedTitle = "🎉 Congratulations!",
            solvedLevelDone = "Level completed ✅",
            continueText = "Next",
            retry = "Retry",
            menu = "Menu",
            selectedImage = { name -> "Selected image: $name" },
            watchAd = "Watch ad",
        )
    } else {
        AppStrings(
            appName = "Neon Puzzle Pro",
            play = "Oyna",
            freePlay = "Serbest Oyun",
            levels = "Leveller",
            settings = "Ayarlar",
            back = "Geri",
            language = "Dil",
            turkish = "Türkçe",
            english = "İngilizce",
            sound = "Ses",
            vibration = "Titreşim",
            dailyReward = "Günlük ödül",
            dailyRewardTitle = "Günlük Ödül",
            dailyRewardText = { amount -> "Günlük giriş bonusu: +$amount coin" },
            ok = "Tamam",
            claim = "Al",
            claimed = "Alındı",
            chooseMode = "Mod seç",
            modeDrag = "Dokun–Değiştir",
            modeSlide = "Klasik Kaydırmalı",
            modeLabel = "Mod",
            level = { id -> "Level $id" },
            openLevel = { id -> "Açık Level: $id" },
            difficultyGrid = { g -> "Zorluk (Grid): ${g}×${g}" },
            continueChoosePhoto = "Devam • Fotoğraf Seç",
            choosePhoto = "Fotoğraf Seç",
            pickFromPhone = "Telefonumdan Seç",
            inGameImagesNote = "Oyun içi görseller (30 level için hazır). İstersen assets/images içine kendi fotoğraflarını koyup bu listeyi değiştirebilirsin.",
            hint = { cost -> "İpucu ($cost)" },
            resetZoom = "Sıfırla",
            moves = "Hamle",
            time = "Süre",
            shuffle = "Karıştır",
            dragHelp = "İpucu: 1 parçaya dokun → seçilir. 2. parçaya dokun → yer değiştirir.",
            slideHelp = "İpucu: Boş kareye komşu parçaya dokun → kayar.",
            solvedTitle = "🎉 Tebrikler!",
            solvedLevelDone = "Level tamamlandı ✅",
            continueText = "Devam",
            retry = "Tekrar",
            menu = "Menü",
            selectedImage = { name -> "Seçilen görsel: $name" },
            watchAd = "Reklam izle",
        )
    }
}

val LocalAppStrings: ProvidableCompositionLocal<AppStrings> =
    staticCompositionLocalOf { stringsFor("en") }

@Composable
@ReadOnlyComposable
fun S(): AppStrings = LocalAppStrings.current

@Composable
@ReadOnlyComposable
fun i18n(): AppStrings = LocalAppStrings.current
