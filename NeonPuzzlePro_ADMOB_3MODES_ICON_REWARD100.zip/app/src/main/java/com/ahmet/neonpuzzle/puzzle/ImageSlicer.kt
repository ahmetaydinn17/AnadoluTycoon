package com.ahmet.neonpuzzle.puzzle

import android.content.ContentResolver
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.InputStream
import kotlin.math.min

object ImageSlicer {

    /**
     * imageRef:
     *  - "asset:img_001.png" => assets/images/img_001.png
     *  - content://... => picked by user
     */
    fun loadBitmap(context: Context, imageRef: String, maxSize: Int = 1024): Bitmap {
        // Daha az RAM kullanımı için iki aşamalı decode (bounds -> inSampleSize)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        openInput(context, imageRef).first.use { BitmapFactory.decodeStream(it, null, bounds) }

        val target = maxSize.coerceAtLeast(256)
        val inSampleSize = calculateInSampleSize(bounds.outWidth, bounds.outHeight, target)

        val opts = BitmapFactory.Options().apply {
            inJustDecodeBounds = false
            this.inSampleSize = inSampleSize
            inPreferredConfig = Bitmap.Config.RGB_565 // yarı bellek (foto için yeterli)
        }

        val decoded = openInput(context, imageRef).first.use {
            BitmapFactory.decodeStream(it, null, opts)
        } ?: throw IllegalStateException("Resim okunamadı")

        val square = centerCropSquare(decoded)
        if (square !== decoded) decoded.recycle()

        val scaled = scaleDown(square, target)
        if (scaled !== square) square.recycle()

        return scaled
    }

    fun slice(bitmap: Bitmap, grid: Int): List<Bitmap> {
        val w = bitmap.width
        val h = bitmap.height
        val pw = w / grid
        val ph = h / grid
        val tiles = ArrayList<Bitmap>(grid * grid)
        for (r in 0 until grid) {
            for (c in 0 until grid) {
                val x = c * pw
                val y = r * ph
                tiles.add(Bitmap.createBitmap(bitmap, x, y, pw, ph))
            }
        }
        return tiles
    }

    private fun openInput(context: Context, ref: String): Pair<InputStream, AutoCloseable?> {
        return if (ref.startsWith("asset:")) {
            val name = ref.removePrefix("asset:")
            // Geriye dönük uyumluluk:
            // - "asset:sample_01.png" => assets/images/sample_01.png
            // - "asset:images/puzzle_1.jpg" => assets/images/puzzle_1.jpg
            val path = if (name.startsWith("images/")) name else "images/$name"
            val stream = context.assets.open(path)
            stream to null
        } else {
            val uri = Uri.parse(ref)
            val stream = context.contentResolver.openInputStream(uri)
                ?: throw IllegalStateException("Uri açılamadı")
            stream to null
        }
    }

    private fun centerCropSquare(src: Bitmap): Bitmap {
        val size = min(src.width, src.height)
        val x = (src.width - size) / 2
        val y = (src.height - size) / 2
        return Bitmap.createBitmap(src, x, y, size, size)
    }

    private fun scaleDown(src: Bitmap, maxSize: Int): Bitmap {
        if (src.width <= maxSize) return src
        val ratio = maxSize.toFloat() / src.width.toFloat()
        val newW = maxSize
        val newH = (src.height * ratio).toInt()
        return Bitmap.createScaledBitmap(src, newW, newH, true)
    }

    private fun calculateInSampleSize(srcW: Int, srcH: Int, req: Int): Int {
        var inSampleSize = 1
        if (srcH > req || srcW > req) {
            var halfH = srcH / 2
            var halfW = srcW / 2
            while ((halfH / inSampleSize) >= req && (halfW / inSampleSize) >= req) {
                inSampleSize *= 2
            }
        }
        return inSampleSize.coerceAtLeast(1)
    }
}
