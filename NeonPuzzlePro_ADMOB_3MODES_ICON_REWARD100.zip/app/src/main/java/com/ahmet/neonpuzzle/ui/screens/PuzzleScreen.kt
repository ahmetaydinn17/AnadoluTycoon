package com.ahmet.neonpuzzle.ui.screens

import android.annotation.SuppressLint
import android.net.Uri
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.TransformableState
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.ahmet.neonpuzzle.PuzzleMode
import com.ahmet.neonpuzzle.ads.AdMobInterstitial
import com.ahmet.neonpuzzle.data.GamePrefs
import com.ahmet.neonpuzzle.puzzle.ImageSlicer
import com.ahmet.neonpuzzle.puzzle.PuzzleEngine
import com.ahmet.neonpuzzle.puzzle.PuzzleState
import com.ahmet.neonpuzzle.puzzle.Tile
import kotlinx.coroutines.delay
import com.ahmet.neonpuzzle.ui.i18n.S

@OptIn(ExperimentalFoundationApi::class)
@SuppressLint("DefaultLocale")
@Composable
fun PuzzleScreen(
    mode: PuzzleMode,
    grid: Int,
    imageRef: String,
    levelId: Int?,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val s = S()

    // Ekonomi
    var coins by remember { mutableStateOf(GamePrefs.coins(context)) }
    val hintCost = remember { GamePrefs.hintCost(context) }

    // Her oyuna girişte 1 interstitial göster (yüklenmişse).
    LaunchedEffect(mode, grid, imageRef) {
        (context as? android.app.Activity)?.let { activity ->
            AdMobInterstitial.showIfReady(activity)
        }
    }

    val runKey = remember(mode, grid, imageRef) { GamePrefs.runKey(mode.name, grid, imageRef) }

    // Kayıtlı run varsa yükle; yoksa yeni oyun.
    fun newStateFromSavedOrFresh(): PuzzleState {
        val saved = GamePrefs.loadRun(context, runKey)
        if (saved != null && saved.tiles.size == grid * grid) {
            val n = grid * grid
            val tiles = saved.tiles.map { id ->
                val isBlank = (mode == PuzzleMode.SLIDE && id == n - 1)
                Tile(id = id, isBlank = isBlank)
            }
            return PuzzleState(mode = mode, grid = grid, tiles = tiles, moves = saved.moves, startMs = saved.startedAtMs)
        }
        return PuzzleEngine.newGame(mode, grid)
    }

    var state by remember { mutableStateOf(newStateFromSavedOrFresh()) }
    var solved by remember { mutableStateOf(PuzzleEngine.isSolved(state)) }

    fun applyHint() {
        if (solved) return
        if (coins < hintCost) return
        GamePrefs.addCoins(context, -hintCost)
        coins -= hintCost
        val newState = PuzzleEngine.applyHint(state)
        state = newState
        solved = PuzzleEngine.isSolved(newState)
    }

    // 20x20 için zoom payı bırakacak şekilde, ama RAM'i patlatmayacak hedef boyut
    val maxSize = remember(grid) {
        when {
            grid >= 15 -> 2048
            grid >= 10 -> 1536
            else -> 1024
        }
    }

    val baseBitmap = remember(imageRef, grid) {
        ImageSlicer.loadBitmap(context, imageRef, maxSize = maxSize)
    }
    val tileBitmaps = remember(baseBitmap, grid) { ImageSlicer.slice(baseBitmap, grid) }
    val tileImages: List<ImageBitmap> = remember(tileBitmaps) { tileBitmaps.map { it.asImageBitmap() } }

    // Timer (state.startMs'ten hesapla)
    var elapsedSec by remember { mutableIntStateOf(0) }
    LaunchedEffect(state.startMs, solved) {
        while (!solved) {
            elapsedSec = (((System.currentTimeMillis() - state.startMs) / 1000L).toInt()).coerceAtLeast(0)
            delay(1000)
        }
        elapsedSec = (((System.currentTimeMillis() - state.startMs) / 1000L).toInt()).coerceAtLeast(0)
    }

    // Her hamlede otomatik kaydet (yarım kalan puzzle unutulmasın)
    LaunchedEffect(state.tiles, state.moves, state.startMs) {
        if (!solved) {
            GamePrefs.saveRun(
                context = context,
                key = runKey,
                tiles = state.tiles.map { it.id },
                moves = state.moves,
                startedAtMs = state.startMs
            )
        }
    }

    // Çözünce: kaydı temizle + level unlock + coin ödülü
    LaunchedEffect(solved) {
        if (solved) {
            GamePrefs.clearRun(context, runKey)

            if (levelId != null) {
                GamePrefs.markLevelCompleted(context, mode.name, levelId)
            }

            // Offline sürüm: leaderboard yok
        }
    }

    // Zoom + pan
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }

    val transformState: TransformableState = rememberTransformableState { zoomChange, panChange, _ ->
        val newScale = (scale * zoomChange).coerceIn(1f, 3f)
        scale = newScale
        offsetX += panChange.x
        offsetY += panChange.y
    }

    // Drag-mode selection (tap to swap)
    var selectedIndex by remember { mutableIntStateOf(-1) }

    fun resetZoom() {
        scale = 1f
        offsetX = 0f
        offsetY = 0f
    }

    fun reshuffle() {
        GamePrefs.clearRun(context, runKey)
        state = PuzzleEngine.newGame(mode, grid)
        selectedIndex = -1
        solved = false
        resetZoom()
    }

    fun handleTap(index: Int) {
        if (solved) return
        when (mode) {
            PuzzleMode.SLIDE -> {
                val newState = PuzzleEngine.trySlideMove(state, index)
                state = newState
                solved = PuzzleEngine.isSolved(newState)
            }
            PuzzleMode.DRAG -> {
                if (selectedIndex == -1) {
                    selectedIndex = index
                } else {
                    if (selectedIndex != index) {
                        val newState = PuzzleEngine.swap(state, selectedIndex, index)
                        state = newState
                        solved = PuzzleEngine.isSolved(newState)
                    }
                    selectedIndex = -1
                }
            }
        }
    }

    val modeText = if (mode == PuzzleMode.DRAG) s.modeDrag else s.modeSlide
    val title = if (levelId != null) s.level(levelId) else modeText

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("$title • ${grid}×${grid}") },
                navigationIcon = { IconButton(onClick = onBack) { Text("←") } },
                actions = {
                    Text("$coins 🪙", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.width(8.dp))
                    TextButton(onClick = ::applyHint, enabled = !solved && coins >= hintCost) {
                        Text(s.hint(hintCost))
                    }
                    TextButton(onClick = ::resetZoom) { Text("⤢") }
                }
            )
        },
        bottomBar = {
            BottomAppBar {
                Text("${s.moves}: ${state.moves}", modifier = Modifier.padding(horizontal = 12.dp))
                Spacer(Modifier.weight(1f))
                Text(String.format("${s.time}: %02d:%02d", elapsedSec / 60, elapsedSec % 60), modifier = Modifier.padding(horizontal = 12.dp))
                Spacer(Modifier.weight(1f))
                TextButton(onClick = ::reshuffle) { Text(s.shuffle) }
            }
        }
    ) { pad ->
        Column(
            modifier = Modifier
                .padding(pad)
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                if (mode == PuzzleMode.DRAG) s.dragHelp else s.slideHelp,
                style = MaterialTheme.typography.bodySmall
            )

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(MaterialTheme.shapes.medium)
                    .background(MaterialTheme.colorScheme.surface)
                    .border(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.35f), MaterialTheme.shapes.medium),
                contentAlignment = Alignment.Center
            ) {
                // Zoomable content
                Box(
                    modifier = Modifier
                        .graphicsLayer(
                            scaleX = scale,
                            scaleY = scale,
                            translationX = offsetX,
                            translationY = offsetY
                        )
                        .transformable(transformState)
                        .padding(10.dp)
                ) {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(grid),
                        userScrollEnabled = false,
                        verticalArrangement = Arrangement.spacedBy(2.dp),
                        horizontalArrangement = Arrangement.spacedBy(2.dp),
                        modifier = Modifier.wrapContentSize()
                    ) {
                        itemsIndexed(state.tiles, key = { idx, _ -> idx }) { idx, tile ->
                            val isSelected = (idx == selectedIndex && mode == PuzzleMode.DRAG)
                            val borderColor = when {
                                isSelected -> MaterialTheme.colorScheme.tertiary
                                tile.isBlank -> MaterialTheme.colorScheme.secondary.copy(alpha = 0.25f)
                                else -> MaterialTheme.colorScheme.secondary.copy(alpha = 0.18f)
                            }

                            Box(
                                modifier = Modifier
                                    .aspectRatio(1f)
                                    .border(1.dp, borderColor)
                                    .background(MaterialTheme.colorScheme.background.copy(alpha = 0.35f))
                                    .clickable { handleTap(idx) },
                                contentAlignment = Alignment.Center
                            ) {
                                if (!tile.isBlank) {
                                    Image(
                                        bitmap = tileImages[tile.id],
                                        contentDescription = "tile",
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                            }
                        }
                    }
                }

                if (solved) {
                    Card(
                        modifier = Modifier.padding(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(s.solvedTitle, style = MaterialTheme.typography.titleLarge)
                            Spacer(Modifier.height(6.dp))
                            Text("${s.moves}: ${state.moves}")
                            Text(String.format("${s.time}: %02d:%02d", elapsedSec / 60, elapsedSec % 60))
                            if (levelId != null) {
                                Spacer(Modifier.height(6.dp))
                                Text(s.solvedLevelDone)
                            }
                            Spacer(Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Button(onClick = {
                                    if (levelId != null) {
                                        // Level ekranına dön (oradan devam)
                                        onBack()
                                    } else {
                                        reshuffle()
                                    }
                                }) {
                                    Text(if (levelId != null) s.continueText else s.retry)
                                }
                                OutlinedButton(onClick = onBack) { Text(s.menu) }
                            }
                        }
                    }
                }
            }

            if (imageRef.startsWith("content:") || imageRef.startsWith("file:")) {
                Text(
                    text = s.selectedImage(Uri.parse(imageRef).lastPathSegment ?: ""),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
