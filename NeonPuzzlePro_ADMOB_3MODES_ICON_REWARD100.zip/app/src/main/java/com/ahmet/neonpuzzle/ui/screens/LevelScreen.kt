package com.ahmet.neonpuzzle.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ahmet.neonpuzzle.PuzzleMode
import com.ahmet.neonpuzzle.ui.i18n.S

@Composable
fun LevelScreen(
    mode: PuzzleMode,
    onBack: () -> Unit,
    onNext: (Int) -> Unit
) {
    var grid by remember { mutableIntStateOf(2) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("${S().modeLabel}: ${if (mode == PuzzleMode.DRAG) S().modeDrag else S().modeSlide}") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Text("←") }
                }
            )
        }
    ) { pad ->
        Column(
            modifier = Modifier
                .padding(pad)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(S().difficultyGrid(grid), style = MaterialTheme.typography.titleLarge)

            Slider(
                value = grid.toFloat(),
                onValueChange = { grid = it.toInt().coerceIn(2, 20) },
                valueRange = 2f..20f,
                steps = 17
            )

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SuggestionChip(
                    onClick = { grid = 2 },
                    label = { Text("2×2") }
                )
                SuggestionChip(
                    onClick = { grid = 4 },
                    label = { Text("4×4") }
                )
                SuggestionChip(
                    onClick = { grid = 10 },
                    label = { Text("10×10") }
                )
                SuggestionChip(
                    onClick = { grid = 20 },
                    label = { Text("20×20") }
                )
            }

            Spacer(Modifier.weight(1f))

            Button(
                onClick = { onNext(grid) },
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) {
                Text(S().continueChoosePhoto)
            }
        }
    }
}
