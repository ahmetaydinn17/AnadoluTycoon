package com.ahmet.neonpuzzle.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.ahmet.neonpuzzle.PuzzleMode
import com.ahmet.neonpuzzle.puzzle.ImageSlicer
import com.ahmet.neonpuzzle.ui.i18n.S

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GalleryScreen(
    mode: PuzzleMode,
    grid: Int,
    onBack: () -> Unit,
    onStartWithAsset: (String) -> Unit,
    onStartWithUri: (Uri) -> Unit,
) {
    val context = LocalContext.current
    // NOTE: S() is @Composable; it can't be called inside remember's calculation.
    // This is cheap to compute and ensures proper recomposition on language change.
    val modeLabel = if (mode == PuzzleMode.DRAG) S().modeDrag else S().modeSlide
    val assetNames = remember {
        // 30 adet hazır puzzle görseli: app/src/main/assets/images/puzzle_1.jpg ... puzzle_30.jpg
        (1..30).map { "images/puzzle_$it.jpg" }
    }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) onStartWithUri(uri)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("${S().choosePhoto} • $modeLabel • ${grid}×${grid}") },
                navigationIcon = { IconButton(onClick = onBack) { Text("←") } }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(
                onClick = {
                    picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                },
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) {
                Text("📱 ${S().pickFromPhone}")
            }

            Text(
                S().inGameImagesNote,
                style = MaterialTheme.typography.bodySmall
            )

            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(assetNames) { name ->
                    val bmp = remember(name) {
                        runCatching { ImageSlicer.loadBitmap(context, "asset:$name", maxSize = 420) }.getOrNull()
                    }
                    Card(
                        modifier = Modifier
                            .aspectRatio(1f)
                            .clickable { onStartWithAsset(name) }
                    ) {
                        if (bmp != null) {
                            Image(
                                bitmap = bmp.asImageBitmap(),
                                contentDescription = name,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Box(Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
                                Text("Resim yok", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }
}
