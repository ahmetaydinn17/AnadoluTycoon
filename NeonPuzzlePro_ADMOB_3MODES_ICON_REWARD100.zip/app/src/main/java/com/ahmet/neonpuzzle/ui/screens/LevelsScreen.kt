package com.ahmet.neonpuzzle.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ahmet.neonpuzzle.PuzzleMode
import com.ahmet.neonpuzzle.data.GamePrefs
import com.ahmet.neonpuzzle.levels.Levels
import com.ahmet.neonpuzzle.ui.i18n.S

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LevelsScreen(
    mode: PuzzleMode,
    onBack: () -> Unit,
    onPlayLevel: (levelId: Int) -> Unit,
) {
    val ctx = LocalContext.current

    var unlocked by remember { mutableIntStateOf(GamePrefs.getUnlockedLevel(ctx, mode.name)) }

    // Compose yeniden çizimde güncel kalsın diye
    LaunchedEffect(mode) {
        unlocked = GamePrefs.getUnlockedLevel(ctx, mode.name)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("LEVELS • ${mode.name}") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Text("←")
                    }
                }
            )
        }
    ) { pad ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(pad)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Text(
                    text = S().openLevel(unlocked),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            items(Levels.all) { level ->
                val isLocked = level.id > unlocked
                val isDone = GamePrefs.isLevelCompleted(ctx, mode.name, level.id)

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .then(
                            if (!isLocked) Modifier.clickable { onPlayLevel(level.id) }
                            else Modifier
                        ),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isLocked) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(level.title, fontWeight = FontWeight.SemiBold)
                            Text(
                                text = "${level.grid}x${level.grid} • ${level.assetName}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        when {
                            isDone -> Text("✅")
                            isLocked -> Text("🔒")
                            else -> Text("▶")
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(12.dp)) }
        }
    }
}
