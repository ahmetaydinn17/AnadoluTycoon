package com.ahmet.neonpuzzle.levels

import android.content.Context

/** Offline (Firebase yok) SharedPreferences helper. */
class GamePrefs(private val context: Context) {

    private val sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun coins(): Int = sp.getInt(KEY_COINS, 0).coerceAtLeast(0)
    fun addCoins(delta: Int) {
        sp.edit().putInt(KEY_COINS, (coins() + delta).coerceAtLeast(0)).apply()
    }

    fun getLastDailyRewardMs(): Long = sp.getLong(KEY_LAST_DAILY, 0L)
    fun setLastDailyRewardMs(ms: Long) { sp.edit().putLong(KEY_LAST_DAILY, ms).apply() }

    fun isSoundOn(): Boolean = sp.getBoolean(KEY_SOUND_ON, true)
    fun setSoundOn(on: Boolean) { sp.edit().putBoolean(KEY_SOUND_ON, on).apply() }

    fun isVibrateOn(): Boolean = sp.getBoolean(KEY_VIBRATE_ON, true)
    fun setVibrateOn(on: Boolean) { sp.edit().putBoolean(KEY_VIBRATE_ON, on).apply() }

    private companion object {
        private const val PREFS = "neon_prefs"
        private const val KEY_COINS = "coins"
        private const val KEY_LAST_DAILY = "last_daily_reward"
        private const val KEY_SOUND_ON = "sound_on"
        private const val KEY_VIBRATE_ON = "vibrate_on"
    }
}
