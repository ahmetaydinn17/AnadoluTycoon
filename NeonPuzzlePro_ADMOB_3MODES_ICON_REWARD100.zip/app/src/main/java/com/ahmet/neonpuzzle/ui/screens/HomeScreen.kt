package com.ahmet.neonpuzzle.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ahmet.neonpuzzle.PuzzleMode
import com.ahmet.neonpuzzle.ads.AdMobBanner
import com.ahmet.neonpuzzle.ads.AdMobRewarded
import com.ahmet.neonpuzzle.data.GamePrefs
import com.ahmet.neonpuzzle.ui.i18n.S

@Composable
fun HomeScreen(
    onStart: (PuzzleMode) -> Unit,
    onGallery: () -> Unit,
    onSettings: () -> Unit,
) {
    val s = S()
    val context = LocalContext.current
    fun watchRewarded() {
        val activity = context as? android.app.Activity ?: return
        AdMobRewarded.showIfReady(
            activity = activity,
            onReward = {
                GamePrefs.addCoins(context, 100)
            }
        )
    }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            s.appName,
            fontSize = 28.sp,
            fontWeight = FontWeight.Black,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            "2×2 → 20×20 • Zoom + Pan • ${s.freePlay}",
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f)
        )

        Spacer(Modifier.height(12.dp))

        ElevatedButton(
            onClick = { onStart(PuzzleMode.DRAG) },
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) {
            Text("🧩 ${s.modeDrag}", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        }

        ElevatedButton(
            onClick = { onStart(PuzzleMode.SLIDE) },
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) {
            Text("🔳 ${s.modeSlide}", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        }

        OutlinedButton(
            onClick = onGallery,
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) {
            Text("🖼 ${s.freePlay}", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        }

        OutlinedButton(
            onClick = onSettings,
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) {
            Text("⚙️ ${s.settings}", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        }

        OutlinedButton(
            onClick = ::watchRewarded,
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) {
            Text("🎁 ${s.watchAd} (+100)", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        }

        Spacer(Modifier.weight(1f))

        AdMobBanner(modifier = Modifier.fillMaxWidth())
    }
}
