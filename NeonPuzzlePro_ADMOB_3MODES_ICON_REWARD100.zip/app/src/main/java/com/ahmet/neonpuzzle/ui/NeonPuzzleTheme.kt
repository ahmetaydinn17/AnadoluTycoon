package com.ahmet.neonpuzzle.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF7C4DFF),
    secondary = Color(0xFF00E5FF),
    tertiary = Color(0xFFFFD54F),
    background = Color(0xFF05060A),
    surface = Color(0xFF0B0D14),
    onPrimary = Color.White,
    onSecondary = Color.Black,
    onBackground = Color(0xFFECECEC),
    onSurface = Color(0xFFECECEC),
)

@Composable
fun NeonPuzzleTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColors,
        typography = androidx.compose.material3.Typography(),
        content = content
    )
}
