package com.ahmet.neonpuzzle.ads

import com.ahmet.neonpuzzle.BuildConfig

/**
 * Production & test ad unit IDs.
 *
 * Debug builds use Google's test IDs to keep the AdMob account safe.
 * Release builds use the real IDs.
 */
object AdIds {

    // ---- Your real AdMob IDs ----
    const val APP_ID = "ca-app-pub-5873234983926555~6489634418"
    const val BANNER = "ca-app-pub-5873234983926555/3490159887"
    const val INTERSTITIAL = "ca-app-pub-5873234983926555/8937927680"
    const val REWARDED = "ca-app-pub-5873234983926555/2866908588"

    // ---- Google's official test IDs ----
    private const val TEST_BANNER = "ca-app-pub-3940256099942544/6300978111"
    private const val TEST_INTERSTITIAL = "ca-app-pub-3940256099942544/1033173712"
    private const val TEST_REWARDED = "ca-app-pub-3940256099942544/5224354917"

    fun bannerUnitId(): String = if (BuildConfig.DEBUG) TEST_BANNER else BANNER
    fun interstitialUnitId(): String = if (BuildConfig.DEBUG) TEST_INTERSTITIAL else INTERSTITIAL
    fun rewardedUnitId(): String = if (BuildConfig.DEBUG) TEST_REWARDED else REWARDED
}
