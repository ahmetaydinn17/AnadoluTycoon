package com.ahmet.neonpuzzle

import android.app.Application
import com.google.android.gms.ads.MobileAds
import com.ahmet.neonpuzzle.ads.AdMobInterstitial
import com.ahmet.neonpuzzle.ads.AdMobRewarded

/**
 * Uygulama başlangıcında AdMob'u hazırlar.
 *
 * Firebase bağımlılıkları projede var; ama Firebase'in gerçekten çalışması için
 * `app/google-services.json` eklemen gerekir.
 */
class NeonPuzzleApp : Application() {
    override fun onCreate() {
        super.onCreate()
        MobileAds.initialize(this) {}
        AdMobInterstitial.preload(this)
        AdMobRewarded.preload(this)
    }
}
