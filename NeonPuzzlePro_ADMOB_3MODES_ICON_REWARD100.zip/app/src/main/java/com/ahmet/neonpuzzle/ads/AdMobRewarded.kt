package com.ahmet.neonpuzzle.ads

import android.app.Activity
import android.content.Context
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewarded.RewardItem
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

object AdMobRewarded {

    private var rewarded: RewardedAd? = null
    private var isLoading = false

    fun preload(context: Context) {
        if (isLoading || rewarded != null) return
        isLoading = true

        RewardedAd.load(
            context,
            AdIds.rewardedUnitId(),
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewarded = ad
                    isLoading = false
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewarded = null
                    isLoading = false
                }
            }
        )
    }

    fun showIfReady(
        activity: Activity,
        onReward: (RewardItem) -> Unit,
        onNotReady: () -> Unit = {},
    ) {
        val ad = rewarded
        if (ad == null) {
            onNotReady()
            preload(activity)
            return
        }

        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                rewarded = null
                preload(activity)
            }

            override fun onAdFailedToShowFullScreenContent(error: com.google.android.gms.ads.AdError) {
                rewarded = null
                preload(activity)
            }
        }

        ad.show(activity) { rewardItem ->
            onReward(rewardItem)
        }
    }
}
