# NeonPuzzlePro (Android Studio Kaynak ZIP)

Bu paket; iki modlu resimli puzzle oyununun (2×2 → 20×20) **çalışan kaynak kodudur**.

## Özellikler
- Mod 1: **Dokun–Değiştir** (modern / hızlı) — iki parçaya dokunup yer değiştir.
- Mod 2: **Klasik Kaydırmalı** (boş kareli hardcore) — boş kareye komşu olanlar kayar.
- **Zoom + Pan**: 2 parmakla yakınlaştır/uzaklaştır, tek parmakla kaydır.
- **Telefon fotoğrafı seçme**: Android Photo Picker.
- **Asset görseller**: `app/src/main/assets/images/` içine istediğin kadar resim koy.

> Not: Bu ZIP "kaynak proje" şeklinde verildi. Gradle Wrapper yok. En hızlı yol: Android Studio'da yeni Compose proje açıp bu dosyaları kopyalamak.

## Android Studio'ya Kurulum (En Kolay)
1) Android Studio → **New Project** → **Empty Activity**
2) Dil: **Kotlin**
3) "Use Jetpack Compose" açık olsun.
4) Oluşan projede şu dosyaları **bu ZIP'tekiyle değiştir**:
   - `app/src/main/java/...` klasörünü komple değiştir
   - `app/build.gradle.kts` ve kökteki `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`
   - `app/src/main/AndroidManifest.xml`
   - `app/src/main/assets/images/` içindeki örnek görselleri de kopyala

Sonra **Sync Now** ve Run.

## 100 Foto Nasıl Eklenir?
`app/src/main/assets/images/` içine 100 tane JPG/PNG at.
Uygulama otomatik listeler.

## Firebase (Leaderboard) Hakkında
Bu kaynakta Firebase ekranı için buton yerleri hazır. Firebase'i kurmak istersen:
- Firebase Console → proje oluştur
- Android app ekle → `google-services.json` al
- Sonra Gradle'a google-services plugin ekleyip Firestore/Analytics dahil edebilirsin.

