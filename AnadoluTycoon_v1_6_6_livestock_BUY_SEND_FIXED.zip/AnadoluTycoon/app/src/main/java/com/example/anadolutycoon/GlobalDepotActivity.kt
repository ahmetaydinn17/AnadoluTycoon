package com.example.anadolutycoon

import android.os.Bundle
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class GlobalDepotActivity : AppCompatActivity() {

    private lateinit var tvMoney: TextView
    private lateinit var lv: ListView
    private lateinit var btnClose: TextView

    private lateinit var moneyStore: GlobalMoneyStore
    private lateinit var depotStore: DepotStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_global_depot)

        moneyStore = GlobalMoneyStore(this)
        depotStore = DepotStore(this)

        tvMoney = findViewById(R.id.tvMoney)
        lv = findViewById(R.id.lvDepot)
        btnClose = findViewById(R.id.btnClose)

        refresh()

        btnClose.setOnClickListener { finish() }
    }

    private fun refresh() {
        tvMoney.text = "Para: ${moneyStore.getMoney()} TL"

        // 7 depo (sıra sende nasıl istiyorsan)
        val maps = listOf(
            MapType.Ciftlik,
            MapType.Koy,
            MapType.Sehir,
            MapType.Madencilik,
            MapType.Hayvancilik,
            MapType.KucukOSB,
            MapType.OSB
        )

        val rows = maps.map { map ->
            val inv = depotStore.getInventory(map)
            val total = inv.values.sum()
            DepotSummaryRow(
                map = map,
                total = total,
                top3 = top3Text(inv)
            )
        }

        lv.adapter = DepotSummaryAdapter(this, rows)
    }

    private fun top3Text(inv: Map<Product, Int>): String {
        val list = inv.entries
            .filter { it.value > 0 }
            .sortedByDescending { it.value }
            .take(3)

        if (list.isEmpty()) return "Boş"

        return list.joinToString(" • ") { (p, q) -> "${p.emoji}${p.title}: $q" }
    }
}
