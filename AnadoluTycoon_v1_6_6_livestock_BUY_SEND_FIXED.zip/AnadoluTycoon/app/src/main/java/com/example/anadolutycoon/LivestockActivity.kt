package com.example.anadolutycoon

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import kotlin.math.max

class LivestockActivity : AppCompatActivity() {

    private val COW_PRICE = 2_000
    private val CHICKEN_PRICE = 500

    private lateinit var depotStore: DepotStore
    private lateinit var moneyStore: GlobalMoneyStore
    private lateinit var livestockStore: LivestockStore
    private lateinit var transferManager: TransferManager

    private val uiHandler = Handler(Looper.getMainLooper())
    private val tickRunnable = object : Runnable {
        override fun run() {
            try {
                checkProductionAndUpdateUI()
            } finally {
                uiHandler.postDelayed(this, 1000L)
            }
        }
    }

    private lateinit var tvTop: TextView
    private lateinit var containerBarns: android.widget.LinearLayout
    private lateinit var containerCoops: android.widget.LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_livestock)

        depotStore = DepotStore(this)
        moneyStore = GlobalMoneyStore(this)
        livestockStore = LivestockStore(this)
        transferManager = TransferManager(depotStore)

        tvTop = findViewById(R.id.tvMoney)

        val btnMainMenu = findViewById<MaterialButton>(R.id.btnMainMenu)
        val btnMapDepot = findViewById<MaterialButton>(R.id.btnMapDepot)
        val btnGlobalDepot = findViewById<MaterialButton>(R.id.btnGlobalDepot)

        btnMainMenu.setOnClickListener {
            startActivity(Intent(this, MainMenuActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
            finish()
        }
        btnMapDepot.setOnClickListener { showMapDepotDialog() }
        btnGlobalDepot.setOnClickListener { startActivity(Intent(this, GlobalDepotActivity::class.java)) }

        containerBarns = findViewById(R.id.containerBarns)
        containerCoops = findViewById(R.id.containerCoops)

        refreshTop()
        renderAllSlots()
    }

    override fun onResume() {
        super.onResume()
        refreshTop()
        renderAllSlots()
        uiHandler.removeCallbacks(tickRunnable)
        uiHandler.post(tickRunnable)
    }

    override fun onPause() {
        super.onPause()
        uiHandler.removeCallbacks(tickRunnable)
    }

    private fun refreshTop() {
        val money = moneyStore.getMoney()
        val stock = depotStore.getInventory(MapType.Hayvancilik).values.sum()
        val yem = depotStore.getInventory(MapType.KucukOSB)[Product.YEM] ?: 0
        tvTop.text = "💰 ${formatMoney(money)} ₺  |  📦 Stok: $stock  |  🌾 Yem(K.OSB): $yem  |  Hayvancılık"
    }

    // ---------------------- UI RENDER ----------------------

    private fun renderAllSlots() {
        containerBarns.removeAllViews()
        containerCoops.removeAllViews()

        val inflater = LayoutInflater.from(this)

        val barns = livestockStore.getBarns()
        val coops = livestockStore.getCoops()

        barns.forEach { barn ->
            containerBarns.addView(createBarnView(inflater, barn))
        }

        coops.forEach { coop ->
            containerCoops.addView(createCoopView(inflater, coop))
        }
    }

    private fun createBarnView(inflater: LayoutInflater, barn: BarnState): View {
        val v = inflater.inflate(R.layout.item_livestock_slot, containerBarns, false)

        val tvTitle = v.findViewById<TextView>(R.id.tvSlotTitle)
        val tvStatus = v.findViewById<TextView>(R.id.tvSlotStatus)
        val btnUnlock = v.findViewById<MaterialButton>(R.id.btnUnlock)
        val btnPlus = v.findViewById<MaterialButton>(R.id.btnPlus)
        val tvCount = v.findViewById<TextView>(R.id.tvCount)
        val btnFeed = v.findViewById<MaterialButton>(R.id.btnFeed)

        tvTitle.text = "🐄 Ahır ${barn.id + 1}"  // kullanıcıya 1..6

        val unlocked = barn.isUnlocked
        val producing = barn.isProducing
        val count = barn.cowCount

        // Kilit / Açık
        val unlockCost = barnUnlockCost(barn.id)
        btnUnlock.visibility = if (unlocked) View.GONE else View.VISIBLE
        btnUnlock.text = "Kilidi Aç (${formatMoney(unlockCost)}₺)"

        tvCount.text = "${count} / 10"

        btnPlus.isEnabled = unlocked && !producing && count < 10
        btnFeed.isEnabled = unlocked && !producing && count > 0

        btnFeed.text = "Besle (45sn)"

        btnUnlock.setOnClickListener {
            val money = moneyStore.getMoney()
            if (money < unlockCost) {
                toast("Yetersiz para")
                return@setOnClickListener
            }
            moneyStore.setMoney(money - unlockCost)
            val barns = livestockStore.getBarns()
            barns[barn.id].isUnlocked = true
            livestockStore.saveBarns(barns)
            refreshTop()
            renderAllSlots()
            toast("✅ Ahır açıldı")
        }

        btnPlus.setOnClickListener {
            if (!barn.isUnlocked) {
                toast("Önce ahırı aç")
                return@setOnClickListener
            }
            if (barn.isProducing) {
                toast("Üretimdeyken hayvan alınamaz")
                return@setOnClickListener
            }
            val barns = livestockStore.getBarns()
            val b = barns[barn.id]
            if (b.cowCount >= 10) {
                toast("Maksimum 10 inek")
                return@setOnClickListener
            }

            confirmBuyAnimal(
                title = "🐄 İnek Satın Al",
                message = "1 adet inek satın alınsın mı?\nÜcret: ${formatMoney(COW_PRICE)}₺",
                price = COW_PRICE
            ) {
                b.cowCount = livestockStore.clampCows(b.cowCount + 1)
                livestockStore.saveBarns(barns)
                refreshTop()
                renderAllSlots()
                toast("✅ 1 inek satın alındı")
            }
        }

        btnFeed.setOnClickListener {
            val barns = livestockStore.getBarns()
            val b = barns[barn.id]
            startBarnProduction(b, barns)
        }

        tvStatus.text = buildStatusText(
            isUnlocked = unlocked,
            isProducing = producing,
            endTime = barn.productionEndTime,
            perAnimalSeconds = 45,
            productEmoji = "🥛",
            productTitle = "Süt",
            animalCount = count
        )

        return v
    }

    private fun createCoopView(inflater: LayoutInflater, coop: CoopState): View {
        val v = inflater.inflate(R.layout.item_livestock_slot, containerCoops, false)

        val tvTitle = v.findViewById<TextView>(R.id.tvSlotTitle)
        val tvStatus = v.findViewById<TextView>(R.id.tvSlotStatus)
        val btnUnlock = v.findViewById<MaterialButton>(R.id.btnUnlock)
        val btnPlus = v.findViewById<MaterialButton>(R.id.btnPlus)
        val tvCount = v.findViewById<TextView>(R.id.tvCount)
        val btnFeed = v.findViewById<MaterialButton>(R.id.btnFeed)

        tvTitle.text = "🐔 Kümes ${coop.id + 1}"

        val unlocked = coop.isUnlocked
        val producing = coop.isProducing
        val count = coop.chickenCount

        val unlockCost = coopUnlockCost(coop.id)
        btnUnlock.visibility = if (unlocked) View.GONE else View.VISIBLE
        btnUnlock.text = "Kilidi Aç (${formatMoney(unlockCost)}₺)"

        tvCount.text = "${count} / 20"

        btnPlus.isEnabled = unlocked && !producing && count < 20
        btnFeed.isEnabled = unlocked && !producing && count > 0
        btnFeed.text = "Besle (30sn)"

        btnUnlock.setOnClickListener {
            val money = moneyStore.getMoney()
            if (money < unlockCost) {
                toast("Yetersiz para")
                return@setOnClickListener
            }
            moneyStore.setMoney(money - unlockCost)
            val coops = livestockStore.getCoops()
            coops[coop.id].isUnlocked = true
            livestockStore.saveCoops(coops)
            refreshTop()
            renderAllSlots()
            toast("✅ Kümes açıldı")
        }

        btnPlus.setOnClickListener {
            if (!coop.isUnlocked) {
                toast("Önce kümesi aç")
                return@setOnClickListener
            }
            if (coop.isProducing) {
                toast("Üretimdeyken hayvan alınamaz")
                return@setOnClickListener
            }
            val coops = livestockStore.getCoops()
            val c = coops[coop.id]
            if (c.chickenCount >= 20) {
                toast("Maksimum 20 tavuk")
                return@setOnClickListener
            }

            confirmBuyAnimal(
                title = "🐔 Tavuk Satın Al",
                message = "1 adet tavuk satın alınsın mı?\nÜcret: ${formatMoney(CHICKEN_PRICE)}₺",
                price = CHICKEN_PRICE
            ) {
                c.chickenCount = livestockStore.clampChickens(c.chickenCount + 1)
                livestockStore.saveCoops(coops)
                refreshTop()
                renderAllSlots()
                toast("✅ 1 tavuk satın alındı")
            }
        }

        btnFeed.setOnClickListener {
            val coops = livestockStore.getCoops()
            val c = coops[coop.id]
            startCoopProduction(c, coops)
        }

        tvStatus.text = buildStatusText(
            isUnlocked = unlocked,
            isProducing = producing,
            endTime = coop.productionEndTime,
            perAnimalSeconds = 30,
            productEmoji = "🥚",
            productTitle = "Yumurta",
            animalCount = count
        )

        return v
    }

    private fun buildStatusText(
        isUnlocked: Boolean,
        isProducing: Boolean,
        endTime: Long,
        perAnimalSeconds: Int,
        productEmoji: String,
        productTitle: String,
        animalCount: Int
    ): String {
        if (!isUnlocked) return "🔒 Kilitli"
        if (animalCount <= 0) return "Hayvan satın al (+)"
        if (!isProducing) {
            return "Hazır değil • Yem: ${animalCount} (K.OSB)\nÜretim: $perAnimalSeconds sn → $productEmoji $productTitle (x$animalCount)"
        }
        val now = System.currentTimeMillis()
        val leftMs = max(0L, endTime - now)
        val leftSec = (leftMs / 1000L).toInt()
        return "⏳ Üretimde • Kalan: ${leftSec}s\nBittiğinde: $productEmoji $productTitle (x$animalCount)"
    }

    // ---------------------- PRODUCTION ----------------------

    private fun startBarnProduction(barn: BarnState, barnsList: MutableList<BarnState>) {
        if (!barn.isUnlocked) {
            toast("Kilitli")
            return
        }
        if (barn.isProducing) {
            toast("Zaten üretimde")
            return
        }
        val count = barn.cowCount
        if (count <= 0) {
            toast("İnek ekle")
            return
        }

        val ok = depotStore.remove(MapType.KucukOSB, Product.YEM, count)
        if (!ok) {
            toast("Yetersiz yem (K.OSB)")
            return
        }

        barn.isProducing = true
        barn.productionEndTime = System.currentTimeMillis() + 45_000L
        barnsList[barn.id] = barn
        livestockStore.saveBarns(barnsList)
        refreshTop()
        renderAllSlots()
        toast("✅ Beslendi → üretim başladı")
    }

    private fun startCoopProduction(coop: CoopState, coopsList: MutableList<CoopState>) {
        if (!coop.isUnlocked) {
            toast("Kilitli")
            return
        }
        if (coop.isProducing) {
            toast("Zaten üretimde")
            return
        }
        val count = coop.chickenCount
        if (count <= 0) {
            toast("Tavuk ekle")
            return
        }

        val ok = depotStore.remove(MapType.KucukOSB, Product.YEM, count)
        if (!ok) {
            toast("Yetersiz yem (K.OSB)")
            return
        }

        coop.isProducing = true
        coop.productionEndTime = System.currentTimeMillis() + 30_000L
        coopsList[coop.id] = coop
        livestockStore.saveCoops(coopsList)
        refreshTop()
        renderAllSlots()
        toast("✅ Beslendi → üretim başladı")
    }

    private fun checkProductionAndUpdateUI() {
        var changed = false
        val now = System.currentTimeMillis()

        val barns = livestockStore.getBarns()
        val coops = livestockStore.getCoops()

        barns.forEach { b ->
            if (b.isUnlocked && b.isProducing && now >= b.productionEndTime) {
                val qty = b.cowCount.coerceAtLeast(0)
                if (qty > 0) depotStore.add(MapType.Hayvancilik, Product.SUT, qty)
                b.isProducing = false
                b.productionEndTime = 0L
                changed = true
            }
        }

        coops.forEach { c ->
            if (c.isUnlocked && c.isProducing && now >= c.productionEndTime) {
                val qty = c.chickenCount.coerceAtLeast(0)
                if (qty > 0) depotStore.add(MapType.Hayvancilik, Product.YUMURTA, qty)
                c.isProducing = false
                c.productionEndTime = 0L
                changed = true
            }
        }

        if (changed) {
            livestockStore.saveBarns(barns)
            livestockStore.saveCoops(coops)
            refreshTop()
            toast("✅ Üretim tamamlandı → Depoya eklendi")
        }

        // timer text güncellemesi için re-render (hafif ama 12 kart olduğu için sorun olmaz)
        renderAllSlots()
    }

    private fun confirmBuyAnimal(
        title: String,
        message: String,
        price: Int,
        onBought: () -> Unit
    ) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Satın Al") { _, _ ->
                val ok = moneyStore.trySpend(price)
                if (!ok) {
                    toast("Yetersiz para")
                    return@setPositiveButton
                }
                onBought()
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    // ---------------------- DEPOT SEND (ÇİFTLİKTEKİ GİBİ) ----------------------

    private fun showMapDepotDialog() {
        val inv = depotStore.getInventory(MapType.Hayvancilik)
        val items = inv.entries.filter { it.value > 0 }.map { it.key }
        if (items.isEmpty()) {
            toast("Hayvancılık deposu boş")
            return
        }

        val arr = items.map { p -> "${p.emoji} ${p.title} • Stok: ${inv[p] ?: 0}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Ürünler / Depo")
            .setItems(arr) { _, which ->
                val p = items[which]
                val stock = inv[p] ?: 0
                showSendTradeDialog(p, stock)
            }
            .setNegativeButton("Kapat", null)
            .show()
    }

    private fun showSendTradeDialog(product: Product, stock: Int) {
        if (stock <= 0) return

        val view = layoutInflater.inflate(R.layout.dialog_trade_product, null)

        val tvTitle = view.findViewById<TextView>(R.id.tvTradeTitle)
        val tvSinglePrice = view.findViewById<TextView>(R.id.tvSinglePrice)
        val tvBulkPrice = view.findViewById<TextView>(R.id.tvBulkPrice)

        val seek = view.findViewById<android.widget.SeekBar>(R.id.seekQty)
        val tvQty = view.findViewById<TextView>(R.id.tvQty)

        val btnSellQty = view.findViewById<MaterialButton>(R.id.btnSellQty)
        val btnSellAll = view.findViewById<MaterialButton>(R.id.btnSellAll)
        val btnSendQty = view.findViewById<MaterialButton>(R.id.btnSendQty)
        val btnSendAll = view.findViewById<MaterialButton>(R.id.btnSendAll)

        // Hayvancılıkta satış yok → butonları gizle
        btnSellQty.visibility = View.GONE
        btnSellAll.visibility = View.GONE
        tvSinglePrice.visibility = View.GONE
        tvBulkPrice.visibility = View.GONE

        tvTitle.text = "${product.emoji} ${product.title} • Stok: $stock"

        seek.max = max(0, stock - 1)
        seek.progress = 0

        var qty = 1
        tvQty.text = "Adet: $qty"

        seek.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: android.widget.SeekBar?, progress: Int, fromUser: Boolean) {
                qty = progress + 1
                tvQty.text = "Adet: $qty"
            }
            override fun onStartTrackingTouch(sb: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(sb: android.widget.SeekBar?) {}
        })

        val dlg = AlertDialog.Builder(this)
            .setView(view)
            .setNegativeButton("Kapat", null)
            .create()

        // GÖNDER
        btnSendQty.setOnClickListener {
            pickSendTarget { target ->
                val ok = depotStore.remove(MapType.Hayvancilik, product, qty)
                if (!ok) {
                    toast("Yetersiz stok!")
                    return@pickSendTarget
                }
                depotStore.add(target, product, qty)
                refreshTop()
                dlg.dismiss()
                toast("📦 Gönderildi: $qty adet → ${target.name}")
            }
        }

        // TÜMÜNÜ GÖNDER
        btnSendAll.setOnClickListener {
            pickSendTarget { target ->
                val cur = depotStore.getInventory(MapType.Hayvancilik)[product] ?: 0
                if (cur <= 0) return@pickSendTarget

                val ok = depotStore.remove(MapType.Hayvancilik, product, cur)
                if (!ok) {
                    toast("Yetersiz stok!")
                    return@pickSendTarget
                }
                depotStore.add(target, product, cur)
                refreshTop()
                dlg.dismiss()
                toast("📦 Tümü gönderildi: $cur adet → ${target.name}")
            }
        }

        dlg.show()
    }

    private fun pickSendTarget(onPicked: (MapType) -> Unit) {
        val targets = listOf(
            MapType.Sehir,
            MapType.OSB,
            MapType.KucukOSB,
            MapType.Ciftlik,
            MapType.Madencilik
        )
        val names = targets.map { it.name }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Nereye gönderilsin?")
            .setItems(names) { _, idx -> onPicked(targets[idx]) }
            .setNegativeButton("İptal", null)
            .show()
    }

    // ---------------------- COSTS ----------------------

    private fun barnUnlockCost(id: Int): Int {
        // 1. Ahır zaten açık. Diğerleri kademeli pahalı.
        return when (id) {
            0 -> 0
            1 -> 5_000
            2 -> 7_500
            3 -> 10_000
            4 -> 12_500
            else -> 15_000
        }
    }

    private fun coopUnlockCost(id: Int): Int {
        return when (id) {
            0 -> 3_000
            1 -> 5_000
            2 -> 7_000
            3 -> 9_000
            4 -> 11_000
            else -> 13_000
        }
    }

    // ---------------------- UTILS ----------------------

    private fun formatMoney(v: Int): String {
        val s = v.toString()
        val sb = StringBuilder()
        for (i in s.indices) {
            sb.append(s[i])
            val left = s.length - i - 1
            if (left > 0 && left % 3 == 0) sb.append('.')
        }
        return sb.toString()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
