package com.example.anadolutycoon

import android.content.Context

class MiningStore(context: Context) {
    private val prefs = context.getSharedPreferences("mining_store", Context.MODE_PRIVATE)

    fun getLast(key: String): Long = prefs.getLong(key, 0L)
    fun setLast(key: String, v: Long) = prefs.edit().putLong(key, v).apply()
}
