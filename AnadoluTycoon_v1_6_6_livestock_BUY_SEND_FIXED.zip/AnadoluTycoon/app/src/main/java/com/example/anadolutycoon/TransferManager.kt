
package com.example.anadolutycoon

class TransferManager(private val depot: DepotStore) {

    fun transfer(from: MapType, to: MapType, p: Product, qty: Int): Boolean {
        if (qty <= 0) return false
        if (!depot.remove(from, p, qty)) return false
        depot.add(to, p, qty)
        return true
    }
}
