package com.example.anadolutycoon

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlin.math.max
import kotlin.math.min

data class BarnState(
    val id: Int,
    var isUnlocked: Boolean = false,
    var cowCount: Int = 0,
    var isProducing: Boolean = false,
    var productionEndTime: Long = 0L
)

data class CoopState(
    val id: Int,
    var isUnlocked: Boolean = false,
    var chickenCount: Int = 0,
    var isProducing: Boolean = false,
    var productionEndTime: Long = 0L
)

/**
 * Yeni Hayvancılık sistemi state deposu.
 * - 6 Ahır + 6 Kümes
 * - Başlangıç: sadece Ahır[1] açık (id=0)
 */
class LivestockStore(context: Context) {

    private val prefs = context.getSharedPreferences("livestock_store_v2", Context.MODE_PRIVATE)
    private val gson = Gson()

    private fun barnsKey() = "barns"
    private fun coopsKey() = "coops"

    fun getBarns(): MutableList<BarnState> {
        val json = prefs.getString(barnsKey(), null)
        if (json.isNullOrBlank()) {
            return defaultBarns()
        }
        return try {
            val type = object : TypeToken<MutableList<BarnState>>() {}.type
            (gson.fromJson<MutableList<BarnState>>(json, type) ?: defaultBarns()).also {
                // güvenlik
                ensureSizes(it, 6) { i -> BarnState(id = i, isUnlocked = i == 0) }
                it.forEach { b ->
                    b.cowCount = b.cowCount.coerceIn(0, 10)
                }
            }
        } catch (_: Exception) {
            defaultBarns()
        }
    }

    fun getCoops(): MutableList<CoopState> {
        val json = prefs.getString(coopsKey(), null)
        if (json.isNullOrBlank()) {
            return defaultCoops()
        }
        return try {
            val type = object : TypeToken<MutableList<CoopState>>() {}.type
            (gson.fromJson<MutableList<CoopState>>(json, type) ?: defaultCoops()).also {
                ensureSizes(it, 6) { i -> CoopState(id = i, isUnlocked = false) }
                it.forEach { c ->
                    c.chickenCount = c.chickenCount.coerceIn(0, 20)
                }
            }
        } catch (_: Exception) {
            defaultCoops()
        }
    }

    fun saveBarns(list: List<BarnState>) {
        prefs.edit().putString(barnsKey(), gson.toJson(list)).apply()
    }

    fun saveCoops(list: List<CoopState>) {
        prefs.edit().putString(coopsKey(), gson.toJson(list)).apply()
    }

    private fun defaultBarns(): MutableList<BarnState> {
        return MutableList(6) { i -> BarnState(id = i, isUnlocked = i == 0) }
    }

    private fun defaultCoops(): MutableList<CoopState> {
        return MutableList(6) { i -> CoopState(id = i, isUnlocked = false) }
    }

    private fun <T> ensureSizes(list: MutableList<T>, target: Int, factory: (Int) -> T) {
        if (list.size < target) {
            val start = list.size
            for (i in start until target) list.add(factory(i))
        } else if (list.size > target) {
            while (list.size > target) list.removeLast()
        }
    }

    // küçük yardımcılar
    fun clampCows(v: Int) = min(10, max(0, v))
    fun clampChickens(v: Int) = min(20, max(0, v))
}
